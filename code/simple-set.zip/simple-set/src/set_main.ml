(* Example of a main executable reading command line arguments.
   Uses Core libaries to parse command line arguments.
   Uses Simple_set for a set data structure (normally would use Core.Set) *)

open Core

(** get file contents as a list of strings **)

let strings_from_file filename =
  let file = In_channel.create filename in
  let strings = In_channel.input_lines file in
  In_channel.close file;
  strings

(**  search for string in file named filename **)

let do_search search_string filename = 
  let s = strings_from_file filename in 
  let my_set = 
    List.fold_right s 
      ~f:(fun elt -> fun (set : 'a Simple_set.t) -> Simple_set.add elt set) 
      ~init:Simple_set.emptyset in
  if Simple_set.contains search_string my_set String.equal then 
    print_string @@ search_string^" found\n" 
  else print_string @@ search_string^" not found\n"

(* This code builds a Command.t which will read the command line and invoke do_search
   No need to understand these fancy Command module details now *)
let command =
  Command.basic 
    ~summary:"Find string line in file" 
    ~readme:(fun () -> "")
    Command.Param.(
      map (both
             (anon ("search_string" %: string))
             (anon ("filename" %: string)))
        ~f:(fun (search_string,filename) ->
            (fun () -> do_search search_string filename)))

(* The above constructs the Command.t data structure, here we run it. *)
let () =
  Command.run ~version:"0.1" ~build_info:"none" command
