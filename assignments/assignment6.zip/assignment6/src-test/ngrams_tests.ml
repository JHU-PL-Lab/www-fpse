
(*
  Here are some incomplete tests to demonstrate basic uses of the n-grams
  executable.
*)

open OUnit2

let string_of_seq (s : char Seq.t) : string =
  let rec protect_seq seq () =
    match seq () with
    | exception End_of_file | Seq.Nil -> Seq.Nil
    | Cons (hd, tl) -> Cons (hd, protect_seq tl)
  in
  String.of_seq (protect_seq s)

(* assert that the output is in the list of expected outputs *)
let assert_string_output (message: string) (expected : string list)
    (cseq : char Seq.t) : unit =
  let actual = String.trim (string_of_seq cseq) in
  assert_bool
    (Printf.sprintf
      "Failed on: %s\n- expected one of: %s\n- actual: %s\n"
      message ("[" ^ String.concat " ; " expected ^ "]" ) actual)
    (List.exists (String.equal actual) expected)

let bin_dir = "../src/bin/" (* note that cwd is _build/default/src-test *)
let test_dir = "../test/"

let exec_name = "ngrams.exe"
let exec_path = Filename.concat bin_dir exec_name

let make_exec args =
  String.concat " " (exec_path :: args)

let test_exec (args : string list) (expected : string list) (ctxt : test_ctxt) : unit =
  assert_command
    ~foutput:(assert_string_output (make_exec args) expected)
    ~ctxt
    exec_path
    args

(*
  --------
  SAMPLING
  --------

  Test that we generate a sequence correctly.
*)

let test_sample
  (max_length : int)       (* max length of output sequence *)
  (filename : string)      (* corpus file*)
  (n : int)                (* size of ngrams *)
  (init : string)          (* initial words of sequence, whitespace separated *)
  (expected : string list) (* list of possible outputs, any of which are correct *)
  : test_ctxt -> unit
  =
  let init_args =
    match init with
    | "" -> []
    | s -> "--initial-words" :: [ s ]
  in
  let sample_args =
    [ "sample" ; Int.to_string max_length
    ; test_dir ^ filename ; Int.to_string n ]
  in
  test_exec (sample_args @ init_args) expected

(*
  Example run with these arguments:
  $ dune exec -- ./src/bin/ngrams.exe sample 26 ./test/ddse.txt 10 --initial-words 'path explosion is a major shortcoming with symbolic execution'
  path explosion is a major shortcoming with symbolic execution a vast number of the explored paths never get near the target program point in forward runs
*)
let sample_test1 =
  let words = "path explosion is a major shortcoming with symbolic execution" in
  let generated = "a vast number of the explored paths never get near the target program point in forward runs" in
  test_sample 26 "ddse.txt" 10 words [ words ^ " " ^ generated ]

(*
  Example runs with these arguments:
  $ dune exec -- ./src/bin/ngrams.exe sample 8 ./test/ddse.txt 3 --initial-words 'while it is'
  while it is defined as a direct generalization
  $ dune exec -- ./src/bin/ngrams.exe sample 8 ./test/ddse.txt 3 --initial-words 'while it is'
  while it is a fundamentally different approach that
*)
let sample_test2 ctxt =
  let words = "while it is" in
  let expected =
    List.map (fun s -> words ^ " " ^ s)
      [ "a useful variation on standard"
      ; "a useful variation on symbolic"
      ; "a useful technique with real"
      ; "a major shortcoming with symbolic"
      ; "a fundamentally different approach that" (* this actually appears in the text *)
      ; "also applicable to other goal"
      ; "also possible to formally prove" (* ... so does this ... *)
      ; "defined as a natural extension" (* ... and this, but the rest of the sentence fragments (along with "it is") are not in the text anywhere *)
      ; "defined as a direct and"
      ; "defined as a direct generalization" ]
  in
  let rec repeat n f =
    if n = 0 then
      ()
    else begin
      f (); repeat (n - 1) f
    end
  in
  (* run this test several times because there is randomness involved *)
  repeat 50 (fun () ->
    test_sample 8 "ddse.txt" 3 words expected ctxt
  )

let sample_tests =
  "Sample" >:::
  [ test_case sample_test1
  ; test_case sample_test2 ]

(*
  ---------
  FREQUENCY
  ---------

  Check that we correctly find the most common ngrams.
*)

let test_frequency
  (k : int)           (* number of ngrams to show *)
  (filename : string) (* corpus file *)
  (n : int)           (* size of ngrams *)
  (expected : string) (* exact expected output *)
  : test_ctxt -> unit
  =
  let args =
    [ "most-frequent" ; Int.to_string k
    ; test_dir ^ filename ; Int.to_string n ]
  in
  test_exec args [ expected ]

(*
  Example run with these arguments:
  $ dune exec -- ./src/bin/ngrams.exe most-frequent 4 ./test/ddse.txt 3
  [
    { "ngram": [ "demand", "driven", "symbolic" ], "count": 4 },
    { "ngram": [ "driven", "symbolic", "evaluator" ], "count": 3 },
    { "ngram": [ "et", "al", "2019" ], "count": 3 },
    { "ngram": [ "for", "imperative", "languages" ], "count": 3 }
  ]
*)
let frequency_test =
  let expected = Yojson.Safe.prettify {|
    [
      { "ngram": [ "demand", "driven", "symbolic" ], "count": 4 },
      { "ngram": [ "driven", "symbolic", "evaluator" ], "count": 3 },
      { "ngram": [ "et", "al", "2019" ], "count": 3 },
      { "ngram": [ "for", "imperative", "languages" ], "count": 3 }
    ]|}
  in
  test_frequency 4 "ddse.txt" 3 expected

let frequency_tests =
  "Frequency" >:::
  [ test_case frequency_test ]

let series =
  "Ngrams tests" >:::
  [ sample_tests
  ; frequency_tests ]