
(*
  One thing which is ubiquitous in many
  object-oriented languages is the abilty to program against
  an interface, and not an underlying class type,
  enabling dependency injection, easier unit testing,
  and encapsulation of implementation details.

  We've seen in OCaml how to use polymorphic functions
  (those involving types like 'a) to operate on any kind of
  data, but this lets us know _nothing_ about the object.

  We've also seen how to hide parts of our implementation
  by not including certain details about types in our mli files
  or module signatures, and not including functions which are
  only meant to be called by some more limited exposed API.

  But how can we write functions which operate on types which
  have a specific interface, rather than "any type"? Imperative
  languages would often use traits or interfaces for this, or simply
  dynamic dispatch and class hierarchies. What's idiomatic in OCaml?
*)


(*
  Turns out, module types and functors do the trick of specifying
  exactly what can be relied upon, and naming our dependencies.

  Better than that, we aren't restricted to specifying only one
  "class" and its interfaces, we can ask for any number and kind
  of functions operating over multiple types, and produce an
  entire module which makes use of those behaviors.

  Using functors in this way decouples our code from the implementation
  of functionality it depends on, and from the representation of objects
  which it uses, allowing a very powerful kind of dependency injection.

  Let's start with a simple case and just consider
  a requirement that some type can be compared for equality:
  (you've seen this type before!)
*)
module type Eq = sig

  (*
    Think of this as the constrained type.
    Because we won't know what it actually is,
    we'll only be allowed to use it with the
    operations defined in this module.
  *)
  type t 

  (*
    This is the only operation we're allowing
    on values of type `t` (for now). This serves as a way
    to allow us to do _some_ things with `t`, but still
    hide away how they work exactly.
  *)
  val (=) : t -> t -> bool

end

(*
  Similarly, next we'll define an interface
  for types which are not only equatable, but orderable:
*)
module type Ord = sig
  (*
    We would like to enforce that instances of `Ord` also
    include the operations from `Eq`. We can do this using the include statement. 
    `include` in OCaml modules is not dissimilar to C's `#include` in that
    you can think of it as pasting the contents of the specified module here
    verbatim.

    In this context, it effectively makes `Ord` an _extension_ of `Eq`. Note that
    using `open` here would not have the same effect, since it would only make
    the contents of `Eq` visible in this scope, but not copy them into it
    completely.
  *)
  include Eq

  (*
    The less-than operator, which, alongside the included
    operations from Eq, can derive any comparison operation.
  *)
  val (<) : t -> t -> bool
end


(*
  Exercise 1:

  Give an example of how the above `Eq` and `Ord` abstractions would be
  represented in a statically-typed OOP programming language you are familiar
  with (of your choice). 
*)

(*
  Comment on how `t` and the other operations are
  represented and related similarly or differently in OCaml compared to this
  language. How is the requirement that `Ord` must include `Eq` represented?

  ... WRITE YOUR ANSWER HERE ...
*)


(*
  Now we've defined an interface, so
  in order to make use of the `Eq` specification,
  we'll also make a simple data structure.
*)
module type Multiset = sig

  (*
    The type of a multiset (AKA a Bag).
    Holds items of some element type, and knows
    how many of each it has, but doesn't necessarily
    have an order imposed on them, unlike a list.
  *)
  type t

  (*
    The element type of the Multiset.

    Notice that neither `t` nor `elt` are subordinate
    or parameters to the other, but the relationship
    between the two is made clear by the available functions.
  *)
  type elt

  val empty : t

  val add : elt -> t -> t

  val count : elt -> t -> int

  (*
    remove does not change the set if the element
    specified was not a member -- it simply returns the set passed.
  *)
  val remove : elt -> t -> t

  (*
    Combines sets such that the count of elements in the union will be
    the sum of the counts of that element for each input set.
  *)
  val union : t -> t -> t

  (*
    Folds in an unspecified order (as this is a set).
    An implementation which folds 'left' or 'right' is acceptable.
  *)
  val fold : t -> init:'acc -> f:('acc -> elt -> 'acc) -> 'acc

end

(*
  Exercise 2:

  Provide an implementation of `Multiset`, making use of
  an unknown module satisfying the `Eq` interface.
  (Feel free to reference the lecture where a very similar
  data structure was implemented)

*)

module Multiset (Elt: Eq): Multiset = struct
  (*
    ... PUT YOUR IMPLEMENTATION HERE ... 
  *)
end

(*
  Does the interface supplied by `Eq` limit your Multiset implementation?
  If so, what might someone deduce about your implementation, knowing
  that it only relies on `Eq` to work?

  ... WRITE YOUR ANSWER HERE ...
*)



(*
  Next, we'll improve our previous assignment's
  dictionary implementation so that any orderable
  type can be used as a key.
*)
module type Dict = sig

  (*
    Like our original definition of dicts, we want the types of values
    to be unconstrained, so they will be the type parameter.
  *)
  type 'a t

  (*
    Rather than strings, this dictionary
    will have keys of some arbitrary orderable type,
    so this type `key` will represent it. 
  *)
  type key

  val empty : 'a t

  val lookup : key -> 'a t -> 'a option

  val map : f:('a -> 'b) -> 'a t -> 'b t

  (*
    Replaces the existing value, if the key already exists.
  *)
  val insert : key -> 'a -> 'a t -> 'a t

  (*
    Returns Some(v) if v was associated with the provided key, or None if there was
    no such key in the dictionary.

    Does not change the dict if the key was not present.
  *)
  val remove : key -> 'a t -> 'a t * 'a option

  (*
    Keeps values from the second argument, when there are duplicate keys.
  *)
  val merge : 'a t -> 'a t -> 'a t

end

(*
  Exercise 3:

  Provide an implementation of `Dict`, making use of an
  unknown module providing the `Ord` interface.

  Feel free to use last assignments' data types to form
  the basis of your implementation, if you like.
  Note you can't use Core.Map "under the covers" here,
  you need to give your own implementation.
*)
module Dict (Key: Ord): Dict = struct
  (*
    ... YOUR IMPLEMENTATION HERE ... 
  *)
end



(*
  Subtle point: "Over-encapsulation"

  The great advantage of programming against the `Eq`
  or `Multiset` interface is precisely not having to know
  what the underlying type `t` is; this
  restricts your dependent code from becoming tightly coupled
  to any particular instantiation of the interface.

  However, the definition of the `Multiset` interface
  makes no distinction between how "hidden" the `t` and `elt`
  types should be. This means that both are only presented
  as abstract types to any code outside the module... but
  we somehow need to create a value of type `elt` in order
  to use any of the multiset's features! We've been so successful
  at hiding the implementation, that we can't even use it.

  Fortunately OCaml has a way to specifically un-hide
  an abstract type in a module signature for this reason.
  Consider the following definition of `Ord` for integers:
*)
module Int_ord: (Ord with type t = int) = struct
  type t = int
  let (=) i1 i2 = Int.equal i1 i2
  let (<) i1 i2 = Int.compare i1 i2 < 0
end

(*
  The module type `(Ord with type t = int)` guarantees that
  all of the contents of `Ord` are satisfied, and additionally
  provides the information that the type `t` is `int`.

  Note that although we specify this type in the type signature,
  we still have to define it in the body of the module;
  try commenting out the "type t = int" declaration within `Int_ord`
  to see this.
*)

(*
  Exercise 4:

  Modify the signature given to `Multiset` and `Dict` in your implementations
  so that they expose the `elt` and `key` types, solving the over-hiding
  problem.

  Hint: remember that you can externally refer to a type ty defined within a module
  Mod by the notation "Mod.ty".  You will need that here.

  Put the improved definitions right here; since they are later in the file they
  will override the ones given above:
*)

(*
  What type does OCaml give to `Multiset(Int_ord)` and `Dict(Int_ord)` after
  doing this? Comment on whether it would be a good idea to also expose `t` in
  this manner in either the Multiset or Dict implementations.
  
    ... WRITE YOUR ANSWER HERE ...
*)



(*
  Exercise 5:

  Given a non-empty list of integers, use your `Multiset` 
  to determine the most frequent element.
*)
let mode (l: int list): int =
  failwith "unimplemented"


(*
  Exercise 6(a):

  Given an integer `n`, use an `int Dict.t ref` to
  design a memoized definition of fibonacci
  which is recursive but does not take exponential time.

  That is, use a Dict to store intermediate answers so they
  do not need to be re-computed if requested again. This should
  work across calls to the top-level function.

  You will need to make use of side-effects/mutability to achieve this,
  and can introduce a global `Dict.t ref` variable to help.
*)
let memoized_fib (n: int): int =
  failwith "unimplemented"

(*
  Exercise 6(b):

  Rather than using a `Dict.t ref` to implement memoization,
  slightly refactor `memoized_fib` from above to use
  a Core.Hashtbl instead.  This implementation will be much
  faster as it can update the memoized values in-place.
*)
let memoized_fib' (n: int): int =
  failwith "unimplemented"



(*
  Exercise 7:

  Is it possible to define a notion of equality on multisets?
  If so, fill out a reasonable implementation below. Give it a module type
  appropriately.

  If not, why? Could a change to `Multiset`, or additional functor arguments
  to `Multiset_eq` accomodate the definition?
  Are the issues with such a definition fundamental or due to
  encapsulation/polymorphism?
*)
module Multiset_eq (Multiset: Multiset) = struct (* ... *) end

(*
  ... YOUR WRITTEN ANSWER HERE IF ANY ...
*)


(*
  Exercise 8:

  Is it possible to define a notion of total ordering on dictionaries?
  If so, fill out a reasonable implementation below. Give it a module type
  appropriately.

  If not, why? Could a change to `Dict`, or additional functor arguments to
  `Dict_ord` accomodate the definition?
  Are the issues with such a definition fundamental or due to
  encapsulation/polymorphism?
*)
module Dict_ord (Dict: Dict) = struct (* ... *) end

(*
  ... YOUR WRITTEN ANSWER HERE IF ANY ...
*)
