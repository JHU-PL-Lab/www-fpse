(*
  FPSE Assignment 3

  Name                  :
  List of Collaborators :

  Please make a good faith effort at listing people you discussed any problems
  with here, as per the course academic integrity policy.

  See file simpledict.mli for the specification of this assignment. Recall from
  lecture that .mli files are module signatures (aka module types), and in this
  file you will need to provide implementations of all the functions listed
  there.

  Note that .ml files need to include all `type` declarations in .mli files.

  You must leave all `[@@deriving show]` annotations, or else your autograder
  won't work. We use this to pretty-print your results.
*)

let unimplemented () =
  failwith "unimplemented"

(* Disables "unused variable" warning from dune while you're still working. *)
[@@@ocaml.warning "-27"]

open Dict_item

type 'a t = 'a Dict_item.t Simpletree.t [@@deriving show]

let empty : 'a t = Simpletree.Leaf

(*
  We implement `size` for you to demonstrate that the Simpletree module
  functions work on the dict since the dict is a specialization of Simpletree.t.

  Utilize this when implementing the rest of the functions. For example, `map`
  should be easy to implement on dictionaries becacuse it's already done on
  trees.
*)
let size (dict : 'a t) : int =
  Simpletree.size dict

let map (f : string -> 'a -> 'b) (dict : 'a t) : 'b t =
  unimplemented ()

let find (key : string) (dict : 'a t) : 'a option =
  unimplemented ()

let set (key : string) (value : 'a) (dict : 'a t) : 'a t =
  unimplemented ()

let keys (dict : 'a t) : string list =
  unimplemented ()

let update (key : string) (f : 'a option -> 'a) (dict : 'a t) : 'a t =
  unimplemented ()

let union (a : 'a t) (b : 'a t) : 'a t =
  unimplemented ()

let merge
  (f : string -> [ `Left of 'a | `Right of 'b | `Both of 'a * 'b ] -> 'c)
  (a : 'a t) (b : 'b t) : 'c t =
  unimplemented ()
