(*
  This file specifies the interface for your code and must not be edited (it
  will not be included in your zip submission).  Your actual implementation
  should go in the file `simpletree.ml` which satisfies this interface
  appropriately.
*)

type 'a t =
  | Leaf
  | Branch of
      { item  : 'a
      ; left  : 'a t
      ; right : 'a t } [@@deriving show]

val size : 'a t -> int
(** [size t] is the number of branches in the tree [t]. Leaves do not count
    towards size. *)

val height : 'a t -> int
(** [height t] is the length of the longest root-to-leaf path in [t]. *)

val is_balanced : 'a t -> bool
(** [is_balanced t] is true if for every branch in [t], the heights of the left
    and right subtrees do not differ by more than 1. *)

val map : ('a -> 'b) -> 'a t -> 'b t
(** [map f t] is a tree where [f] has been applied to every value in [t], where
    the shape of the tree is the same as [t]. *)

val fold_left : ('acc -> 'a -> 'acc) -> 'acc -> 'a t -> 'acc
(** [fold_left f acc t] is left-to-right in-order folding of the branches in
    [t], where [acc] is the base case for folding function [f].

    E.g. fold_left (+) 0 t where t is

          3
        /  \
       1    4
      / \    \
     0   2    5

     computes (((((0 + 0) + 1) + 2) + 3) + 4) + 5
  *)

val is_ordered : ('a -> 'a -> int) -> 'a t -> bool
(** [is_ordered compare t] is true if for every branch in [t], all left subtree
    items are strictly less than the branch item, and all right subtree items
    are strictly greater, according to [compare].

    Note that this requirement guarantees (by induction) that the tree has no
    duplicate items. *)
