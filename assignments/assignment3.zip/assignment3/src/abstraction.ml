(*

FPSE Assignment 3

Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any 
problems with here, as per the course academic integrity policy.  

*)

(*
  One thing which is ubiquitous in many
  object-oriented languages is the abilty to program against
  an interface, and not an underlying class or type,
  enabling dependency injection, easier unit testing,
  and encapsulation of implementation details.

  We've seen in OCaml how to use polymorphic functions
  (those involving types like 'a) to operate on any kind of
  data, but this lets us know _nothing_ about the object.

  We've also seen how to hide parts of our implementation
  by not including certain details about types in our mli files
  or module signatures, and not including functions which are
  only meant to be called by some more limited exposed API.

  But how can we write functions which operate on types which
  have a specific interface, rather than "any type"? Imperative
  languages would often use traits or interfaces for this, or simply
  dynamic dispatch and class hierarchies. What's idiomatic in OCaml?
*)

(*
  Turns out, module types and functors do the trick of specifying
  exactly what can be relied upon, and naming our dependencies.

  Better than that, we aren't restricted to specifying only one
  "class" and its interfaces, we can ask for any number and kind
  of functions operating over multiple types, and produce an
  entire module which makes use of those behaviors.

  Using functors in this way decouples our code from the implementation
  of functionality it depends on, and from the representation of objects
  which it uses, allowing a very powerful kind of dependency injection.

  Let's start with a simple case and just consider
  a requirement that some type can be compared for equality:
  (you've seen this type before!)
*)
module type Eq = sig
  (*
    Think of this as the constrained type.
    Because we won't know what it actually is,
    we'll only be allowed to use it with the
    operations defined in this module.
  *)
  type t

  (*
    This is the only operation we're allowing
    on values of type `t` (for now). This serves as a way
    to allow us to do _some_ things with `t`, but still
    hide away how they work exactly.
  *)
  val ( = ) : t -> t -> bool
end

(*
  Similarly, next we'll define an interface
  for types which are not only equatable, but orderable:
*)
module type Ord = sig
  (*
    We would like to enforce that instances of `Ord` also
    include the operations from `Eq`. We can do this using the include statement. 
    `include` in OCaml modules is not dissimilar to C's `#include` in that
    you can think of it as pasting the contents of the specified module here
    verbatim.

    In this context, it effectively makes `Ord` an _extension_ of `Eq`. Note that
    using `open` here would not have the same effect, since it would only make
    the contents of `Eq` visible in this scope, but not copy them into it
    completely.
  *)
  include Eq

  val ( < ) : t -> t -> bool
end

(*
  Let us improve our previous assignment's dictionary implementation 
  so that any orderable type can be used as a key.
*)
module type Dict = sig
  (*
    Like our original definition of dicts, we want the types of values
    to be unconstrained, so they will be the type parameter.
  *)
  type 'a t

  (*
    Rather than strings, this dictionary
    will have keys of some arbitrary orderable type,
    so this type `key` will represent it. 
  *)
  type key

  val empty : 'a t

  val lookup : key -> 'a t -> 'a option

  val is_well_formed_dict : 'a t -> bool

  val map : f:('a -> 'b) -> 'a t -> 'b t
  
  val insert : key -> 'a -> 'a t -> 'a t

  (*
    `remove` returns Some(v) if v was associated with the provided key, 
    or None if there is no such key in the dictionary.

    Does not change the dict if the key was not present.
  *)
  val remove : key -> 'a t -> 'a t * 'a option

  (*
    Keeps values from the second argument, when there are duplicate keys.
  *)
  val merge : 'a t -> 'a t -> 'a t
end

(*
  Exercise 1:

  Provide an implementation of `Dict`, making use of an
  unknown module providing the `Ord` interface.

  Feel free to use last assignments' data types to form
  the basis of your implementation, if you like.
  Note you can't use Core.Map "under the covers" here,
  you need to give your own implementation.
*)
module Dict (Key : Ord) : Dict = struct
  (*
    ... YOUR IMPLEMENTATION HERE ... 
  *)
end

(*
  Subtle point: "Over-encapsulation"

  The great advantage of programming against the `Ord`
  or `Dict` interface is precisely not having to know
  what the underlying type `t` is; this
  restricts your dependent code from becoming tightly coupled
  to any particular instantiation of the interface.

  However, the definition of the `Dict` interface
  makes no distinction between how "hidden" the `t` and `elt`
  types should be. This means that both are only presented
  as abstract types to any code outside the module... but
  we need to create a value of type `elt` in order
  to use any of the Dict's features! We've been so successful
  at hiding the implementation, that we can't even use it.

  Fortunately OCaml has a way to specifically un-hide
  an abstract type in a module signature for this reason.
  Consider the following definition of `Ord` for integers:
*)
module Int_ord : Ord with type t = int = struct
  type t = int

  let ( = ) i1 i2 = Int.equal i1 i2

  let ( < ) i1 i2 = Int.compare i1 i2 < 0
end

(*
  The module type `(Ord with type t = int)` guarantees that
  all of the contents of `Ord` are satisfied, and additionally
  provides the information that the type `t` is `int`.

*)

(*
  Exercise 2:

  Modify the signature given to `Dict` in your implementation
  so that they expose the `elt` and `key` types, solving the over-hiding
  problem so that the data structure can finally be used.

  Hint: remember that you can externally refer to a type ty defined within a module
  Mod by the notation "Mod.ty".  You will need that here.

  Put the improved definitions right here; since they are later in the file they
  will override the ones given above:
*)

(*
  Exercise 3(a):

  Given an integer `n`, use an `int Dict.t ref` to
  design a memoized definition of fibonacci
  which is recursive but does not take exponential time.

  That is, use a Dict to store intermediate answers so they
  do not need to be re-computed if requested again. This should
  work across calls to the top-level function.

  You will need to make use of side-effects/mutability to achieve this,
  and can introduce a global `Dict.t ref` variable to help.
*)
let memoized_fib (n : int) : int = failwith "unimplemented"

(*
  Exercise 3(b):
  Repeat the above but using the built-in functional dictionary, a Map.t ref
*)
let memoized_fib' (n : int) : int = failwith "unimplemented"

(*
  Exercise 3(c):

  The above approaches are not optimal: if you are making 
  a mutable structure you should use one which supports
  fine-grained mutation instead of only global replacement
  as in the above.  So, refactor `memoized_fib` from above to use
  a Core.Hashtbl (Core's mutable map/dict) instead.  This implementation 
  will be much faster as it can update the memoized values in-place.
*)
let memoized_fib'' (n : int) : int = failwith "unimplemented"

(*
  Exercise 4:

  For this question we will develop a generic operator language parser / evaluator.
  We will make it generic by allowing us to "plug in" the underlying data type.

  Note we will simplify several things so this is primarily an OCaml abstraction
  exercise and not a parsing exercise.  We will have only `+` and `*` binary
  operations, will just parse a string rather than reading from a stream, and 
  will use postfix (aka RPN) notation for operators: "1 2 +" will return 3.
  
*)

(* Here is the module type for the underlying data.
   The key function is next, it reads a `t` off of the front of the string,
   and returns the remainder of the string as well as the `t` element.

   Here are some clarifications on how next works.
   1. whitespace (space, tab, newline) is a separator, the `t` value ends at that point.
   2. `next` is only reponsible for reading a `t` off the front of the string
   3. It should obey the "maximal munch" principle, read in as many characters as possible
     whilst still making a `t`.  So for example on input `"12"` for `t = int` read in `12`, not `1`.
     On "12@" next will return `12` plus remainder "@", `next` is not responsible for checking 
     for other errors.
   4. `next` will return `None` if there is no `t` to read from the front of the string.  So for example is the string starts with a non-digit or `-` for the case of integers.
*)

module type Data = sig
  type t

  val from_string : string -> t

  val to_string : t -> string

  val next : string -> (string * t) option

  val plus : t -> t -> t

  val times : t -> t -> t
end

(* The Evaluator for this simple language is then a functor of this type. 
   If the input cannot be parsed, `eval` will return `Error "string"`, otherwise it will
   return `Some(t-value)`. 
   
   Clarifications:
   1. If an illegal character is encountered, the evaluator will return `Error "illegal character"`.
   2. If there are too few or too many operators (as in "1 2 + +" or "1 2") return `Error "unmatched"
   3. Note that operators need not be space-separated, e.g. "1 2 3++" returns `6`.
   4. '+' and '*' are the characters corresponding to the `plus` and `times` binary operations. 
     There are no other operations supported, all others are illegal characters.
   *)

module type Eval = functor (Data : Data) -> sig
  type t = Data.t

  val eval : string -> (t , string) result
end

(* a. Write the evaluator functor matching this signature.  *)

(* Uncomment this code and fill in the ...

module Eval : Eval = functor (Data : Data) -> struct
  ...
end

*)

(* b. Make Int_Data and Rat_Data modules for parsing integers and rationals. 

    - Integers may optionally be signed, so -4 is an integer 
    - Rationals are written as "3/4", integers separated by "/".  They also may be signed
with a signed prefix (only in numerator, "3/-4" is not a rational).
    *)

(* remove this comment and fill in: 

module Int_Data : Data = struct ... end 

*)

(* remove this comment and fill in: 

module Rat_Data : Data = struct ... end 

*)

(* With this we may now create evaluators for integers and rationals. *)

(* Uncomment the below lines (unchanged) when you have the above modules defined. 

module Int_Eval = Eval(Int_Data)

module Rat_Eval = Eval(Rat_Data)
*)

(*
Int_Eval.eval "2 3 +" should now return `OK(5)
*)