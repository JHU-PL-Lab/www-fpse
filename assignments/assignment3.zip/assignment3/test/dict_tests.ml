
open OUnit2

module D = Simpledict
module I = Dict_item
module T = Simpletree

let singleton k v =
  T.Branch { item = { I.key = k ; value = v } ; left = T.Leaf ; right = T.Leaf }

let d1 = T.Branch
  { item = { I.key = "b" ; value = 1 }
  ; left = singleton "a" 2
  ; right = singleton "c" 3 }

let d2 = T.Branch
  { item = { I.key = "b" ; value = 10 }
  ; left = singleton "a" 20
  ; right = T.Leaf }

let test_empty_and_size _ =
  assert_equal 0 (D.size D.empty);
  assert_equal 3 (D.size d1)

let test_map _ =
  let d' = D.map (fun k v -> String.length k + v) d1 in
  (* a -> 1+2, b -> 1+1, c -> 1+3 *)
  assert_equal 3 @@ Option.get (D.find "a" d');
  assert_equal 2 @@ Option.get (D.find "b" d');
  assert_equal 4 @@ Option.get (D.find "c" d')

let test_set_and_find _ =
  let d = D.set "k" 7 D.empty in
  assert_equal (Some 7)  @@ D.find "k" d;
  (* Overwrite *)
  let d2 = D.set "k" 42 d in
  assert_equal (Some 42) @@ D.find "k" d2;
  assert_equal None @@ D.find "zzz" d2

(* The following tests require set to work *)

let test_keys _ =
  let d =
    List.fold_left
      (fun acc (k,v) -> D.set k v acc)
      D.empty
      [("x",1);("a",2);("m",3)]
  in
  assert_equal ["a";"m";"x"] @@ D.keys d

let test_update _ =
  let d = D.set "p" 9 d1 in
  (* update existing *)
  let d_upd = D.update "p" (function None -> 0 | Some v -> v * 2) d in
  assert_equal (Some 18) @@ D.find "p" d_upd;
  (* insert new *)
  let d_upd2 = D.update "q" (function None -> 7 | Some v -> v * 7) d_upd in
  assert_equal (Some 7) @@ D.find "q" d_upd2

let test_union _ =
  let d3 = D.union d1 d2 in
  (* b gets value from d2, a gets value from d2, c only in d1 *)
  assert_equal (Some 10) @@ D.find "b" d3;
  assert_equal (Some 20) @@ D.find "a" d3;
  assert_equal (Some 3) @@ D.find "c" d3

let test_merge _ =
  let merged = D.merge (fun _ -> function
      | `Left x -> x * 2
      | `Right y -> y * 3
      | `Both (x, y) -> x * y
    ) d1 d2
  in
  assert_equal (Some 40) @@ D.find "a" merged;
  assert_equal (Some 10) @@ D.find "b" merged;
  assert_equal (Some 6) @@ D.find "c" merged;
  assert_equal None @@ D.find "y" merged

let series =
  "simpledict tests" >:::
    [ "empty_and_size" >:: test_empty_and_size
    ; "map" >:: test_map
    ; "set_and_find" >:: test_set_and_find
    ; "keys" >:: test_keys
    ; "update" >:: test_update
    ; "union" >:: test_union
    ; "merge" >:: test_merge ]