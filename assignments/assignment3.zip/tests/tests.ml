(*
 * Part II: Tests
 *
 * In this part, you will need to create and run your own tests.  Tests should
 * cover both common cases and edge cases.  In previous assignments, we only
 * asked for a specified number of additional tests, but in this assignment we
 * will be grading based on code coverage.
 *
 * We expect complete code coverage on * all functions (even the
 * N_grams.sample_sequence function, which we will ask you to test in order to
 * understand what it does), and we will check by running the bisect tool on
 * your code.  For that reason, you need to add the following line in your
 * dune file:
 *     
 *     (preprocess (pps bisect_ppx))
 *
 * or else your tests will not run in the autograder.
 *
 * Also, see the homework description on the webpage for assertions you will 
 * need to add to your code in abstraction.ml for Part II.
 *)

open Core
open OUnit2


