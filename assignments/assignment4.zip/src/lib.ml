
open Core

(*
  In this assignment we'll implement something cool using
  the ability to abstract over orderable types of values. You'll develop
  a command line tool which makes use of this library file.

  Using the n-gram model of sequences and probabilities, we'll take in
  some sequence of items, and then use it as a basis to generate more similar
  sequences (for example, sentences of words, lists of numbers, etc.),
  or evaluate the likelihood of seeing particular sequences.

  First we'll need some helper functions and definitions.
*)

(*
  Exercise 1:

  Given a list of some type, and a positive integer `n`,
  produce a list of contiguous subsequences of length `n`
  of the original list. If `n` is greater than the length
  of the input, return an empty list.

  E.G.
    chunks 3 [1; 2; 3; 4; 5] =
      [ [1;2;3]; [2;3;4]; [3;4;5] ]

    chunks 2 ["a"; "b"; "c"; "d"; "e"] =
      [ ["a";"b"]; ["b";"c"]; ["c";"d"]; ["d";"e"] ]

    chunks 3 [1; 2] = []
*)
let chunks (n: int) (l: 'a list): 'a list list =
  failwith "undefined"


(*
  Exercise 2:

  Given a non-empty list of some type, return a pair
  of the last element, and a list of all previous elements.
  This should take O(n) time.

  E.G.
    split_last [1;2;3] = (3, [1;2])
*)
let split_last (l: 'a list): 'a * 'a list =
  failwith "undefined"


(*
  Exercise 3:

  Given a data type which can be used as the key
  for a map, show that a list of this type can also
  be used as a map key.
*)
module List_key (Elt: Map.Key): (Map.Key with type t = Elt.t list) = struct
  (*
    ... YOUR IMPLEMENTATION HERE ... 
  *)
end



(*
  We will need randomness for this code, which can make things hard to test.
  To help solve this problem, the following module type will be how randomness
  is accessed from within your code (either as a functor argument, or first-class module).

  Note that the standard `Base.Random` module is compatible with this type,
  but you could also provide alternative definitions which give more debug info,
  guarantee a certain sequence of numbers, log to stderr, etc.
*)
module type Randomness = sig
  (*
    Given a maximum integer value, return
    a pseudorandom integer from 0 (inclusive) to this value (exclusive).
  *)
  val int : int -> int
end


(*
  Exercise 4:

  Given a multiset (also known as a bag) select one element
  from it with uniform probability (so that elements which
  appear multiple times should have a higher chance to be picked).
  Or, if the bag is empty, return None.

  See the (weighted) reservoir sampling algorithms
  for a simple potential approach to this.
  
  Use `Core.Bag` for your bag as can be seen in the type below.
  This operation should not be destructive or mutate the bag, it
  should just extract a random element.
  Be aware that Core.Bag is a mutable data structure, in general.
  Also be aware of the `'a Bag.Elt.t` type, which signifies a particular
  element within the Bag (distinguishing it from other, possibly equal elements).
  Several Bag functions take and return `'a Bag.Elt.t` values so look
  at the documentation for `Bag.Elt` to see how to e.g. extract the underlying value.

  Note that `Bag.choose` does *not* satisfy this definition;  it simply 
  picks the first element always

*)
let sample (module R: Randomness) (b: 'a Bag.t): 'a option =
  failwith "undefined"



(*
  This module will implement a very common probabilistic model of sequences
  of elements known as the N-gram model, or sometimes called the Markov model.

  The general intuition is simple: if we want to be able to predict
  what comes next in a sequence of items, we can probably do so on the basis of the
  elements which preceeded it. Moreover, we can probably ignore parts of the
  sequence which came _far_ before the element we want to predict, and focus
  our attention on the immediately previous couple of items.

  Consider sentences of words in english text, a very common type of sequence to apply
  this approach to. If we are given that the word we want to predict came after:
  
  "take this boat for a spin out on the" ???

  Then we could say that "water" is more likely than "town" to follow.
  If we have less context, say only 2 words:

  "on the" ???

  We will naturally make a poorer approximation of the true distribution,
  but it may be sufficient for some purposes anyway, and will be easier to estimate.
  How can we estimate the actual distribution of words efficiently, then?
  
  We will need to take in some observed sequence of words or tokens, called a _corpus_.
  Let's say we want to keep 2 words of context when predicting what comes next, based on
  the provided corpus. Then we can just keep track of every 3-tuple of consecutive words in the input,
  and count how often they appear.

  For example, say we observe the triples:
  ("take", "this", "boat"), ("this", "boat", "for"), ... ("on", "the", "water").

  Then, if we index these properly, we can predict what should follow ("on", "the") by
  just sampling randomly from among all the tuples which started with that prefix, and using
  the last element of the tuple as our prediction.
  Naturally, words which appear more frequently in the context specified should then
  be given more weight, and words which do not appear in our corpus after the given sequence
  will not be chosen at all, so our prediction will be a reasonable estimate for the
  empirical distribution.

  Clearly, if we instead count 5-tuples rather than 3-tuples, we can make predictions with
  greater context, and more closely match the true sequence properties. However, we will
  also be able to observe fewer unique 5-tuples overall than 3-tuples, which will mean we need
  greater amounts of data to properly use a larger n-gram size.


  Feel free to read these useful resources to understand the basic idea further:
  - https://blog.xrds.acm.org/2017/10/introduction-n-grams-need/
  - https://web.stanford.edu/~jurafsky/slp3/slides/LM_4.pdf
  - https://medium.com/mti-technology/n-gram-language-model-b7c2fc322799

  
  Now we'll define a module which holds our main functionality
  specific to a particular orderable type we'll call `Token`. These
  tokens could be words of course, but could also be numbers, or
  DNA base pairs, etc.

  We also need randomness here, so we will abstract over it as well.
*)
module N_grams (Random: Randomness) (Token: Map.Key) = struct

  (*
    Define a module which satisfies the signature provided,
    so that sequences of tokens can be mapped to values.
  *)
  module Token_list_map : (Map.S with type Key.t = Token.t list);;


  (*
    Based on how n-grams work, we will represent a probability distribution
    as mapping from prefixes of size `n`, to tokens which followed this prefix
    in our training corpus. The more times any particular token follows a prefix,
    the more likely it is to follow it again.
  *)
  type distribution = Token.t Bag.t Token_list_map.t

  (*
    Exercise 5:

    Given a positive integer `n` and a list of tokens,
    add each token to a new distribution as an element of the set
    corresponding to the (n-1)-gram which preceeds it.

    E.G. (with maps/bags depicted with pseudo-syntax)

      ngrams 2 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        { 
          [1] -> {2}; 
          [2] -> {3; 2; 3};
          [3] -> {4; 1};
          [4] -> {4; 4; 2};
            |        |
            |        \------- ...was followed by each of these elements
            \-- this sequence...
        }

      ngrams 3 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        {
          [1; 2] -> {3};
          [2; 3] -> {4; 1};
          [3; 4] -> {4};
          [4; 4] -> {4; 2};
          [4; 2] -> {2};
            |        |
            |        \------- ...was followed by each of these elements
            \-- this sequence...
        }

      ngrams 1 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        {
          [] -> {1; 2; 3; 4; 4; 4; 2; 2; 3; 1};
          |        |
          |        \------- ...was followed by each of these elements
          \-- this sequence...
        }
  *)
  let ngrams (n: int) (l: Token.t list): distribution =
    failwith "undefined"


  (*
    Exercise 6:

    Now, we're prepared to use the output of `ngrams` to create new,
    randomly sampled sequences.

    The arguments it expects are as follows:
    - an output from a call to `ngrams n` (above) representing a distribution
    - an integer for the maximum length of sequence to generate
    - a list of tokens (of length `n-1`) to kick-off the random generation and sequence
      (consider it like a 'seed' for you to look up in the distribution)

    It will then produce a sequence which is distributed according
    to the n-gram model it is given, terminating it either when the resulting
    sequence reaches the maximum length, or when there are no observed
    n-grams which could follow.
  *)
  let sample_sequence (dist: distribution) ~(max_length: int) ~(initial_ngram: Token.t list): Token.t list =
    failwith "undefined"
  

end

(*
  Exercise 7:

  In utop, or in whatever manner is most convenient, try out the `sample_sequence` function
  on various kinds of inputs (and instantiations of this N_grams module).

  Can you get interesting results by giving it sequences of words?
  Below, paste some sequence data which you tried inputting to `ngrams`,
  and then 3 examples of sampled sequences generated with `sample_sequences`
  and `ngrams` with different values of `n`.
*)

(*
  ... YOUR SEQUENCE OF DATA HERE ...
*)

(*
  ... YOUR OUTCOMES OF SAMPLING SEQUENCES HERE ...
*)    

(* Part II starts here *)

(*
  Exercise 8:

  Given a string, perform basic sanitization/normalization
  by taking the following steps:

  - remove all characters not in the range [a-zA-Z0-9]
  - convert all characters [A-Z] to lowercase

  if the resulting string is empty, return None.

*)
let sanitize (s: string): string option =
  failwith "unimplemented"

(*
  Exercise 9:

  Implement an executable `ngrams.exe` which can use n-gram models in several ways.
  It should expect to be called with the following arguments, with bracketed ones optional:

    $ ngrams.exe N CORPUS-FILE [--sample SAMPLE-LENGTH [INITIAL-WORDS...]] [--most-frequent N-MOST-FREQUENT]

  
  Functionality should be as follows:

  - Load the file specified by `CORPUS-FILE` and split its contents into a
    sequence of strings based on whitespace. Treat newlines and spaces, etc. equally.

  - Sanitize each of the strings in this sequence according to the `sanitize` function,
    removing all strings which end up as `None` in this way, to produce a new sequence.

  - Initialize an n-gram distribution using `N` and the sanitized sequence of words.

  
  If the option `--sample SAMPLE-LENGTH` is provided:

    To stdout, output a sequence of `SAMPLE-LENGTH` words randomly sampled from the n-gram model.
    Print them out separated by single spaces. 
    
    To begin the sequence, use the `INITIAL-WORDS` arguments
    provided after `--sample` to seed the sequence, or if none are provided, 
    choose a random starting n-gram to begin. You may assume that the words
    provided as `INITIAL-WORDS` are already sanitized, and that there are 
    at least (`N` - 1) of them.

  If the option `--most-frequent N-MOST-FREQUENT` is provided:
  
    To stdout, output a sorted JSON-formatted array of length `N-MOST-FREQUENT`
    containing information about the most common n-grams seen in the `CORPUS-FILE`, like so:

    [
      { 
        "ngram": ["array", "of", "strings", ...],
        "frequency": <number of times witnessed>
      },
      ...
    ]

  You may assume that only one of `--sample` or `--most-frequent` will be
  supplied at a time, and that at least one will be given.

  To output JSON, you may again use yojson and `ppx_deriving_yojson`,
  and to parse command line arguments, we recommend looking into
  the `Core.Command` module.
  See Real World OCaml Chapter 14 https://dev.realworldocaml.org/command-line-parsing.html
  for some examples of Core.Command in action.
*)
