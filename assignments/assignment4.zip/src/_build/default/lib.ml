
open Core


(*
  In this assignment we'll implement something (not too complicated, but cool) using
  the ability to abstract over orderable types of values. You'll develop
  a command line tool which makes use of this library file.

  Using the n-gram model of sequences and probabilities, we'll take in
  some sequence of items, and then use it as a basis to generate more similar
  sequences (for example, sentences of words, lists of numbers, etc.),
  or evaluate the likelihood of seeing particular sequences.

  First we'll need some helper functions and definitions.
*)

(*
  Exercise 1:

  Given a list of some type, and a positive integer `n`,
  produce a list of contiguous subsequences of length `n`
  of the original list. If `n` is greater than the length
  of the input, return an empty list.

  E.G.
    chunks 3 [1; 2; 3; 4; 5] =
      [ [1;2;3]; [2;3;4]; [3;4;5] ]

    chunks 2 ["a"; "b"; "c"; "d"; "e"] =
      [ ["a";"b"]; ["b";"c"]; ["c";"d"]; ["d";"e"] ]

    chunks 3 [1; 2] = []
*)
let chunks (n: int) (l: 'a list): 'a list list =
  failwith "undefined"



(*
  Exercise 2:

  Given a non-empty list of some type, return a pair
  of the last element, and a list of all previous elements.
  This should take O(n) time.

  E.G.
    split_last [1;2;3] = (3, [1;2])
*)
let split_last (l: 'a list): 'a * 'a list =
  failwith "undefined"


(*
  Exercise 3:

  Given a data type which can be used as the key
  for a map, show that a list of this type can also
  be used as a map key.
*)
module List_key (Elt: Map.Key): (Map.Key with type t = Elt.t list) = struct
  (*
    ... YOUR IMPLEMENTATION HERE ... 
  *)
end



(*
  We will need randomness for this code, which can make things hard to test.
  To help solve this problem, the following module type will be how randomness
  is accessed from within your code (either as a functor argument, or first-class module).

  Note that the standard `Random` module is compatible with this type,
  but you could also provide alternative definitions which give more debug info,
  guarantee a certain sequence of numbers, log to stderr, etc.
*)
module type Randomness = sig
  (*
    Given a maximum integer value, return
    a pseudorandom integer from 0 (inclusive) to this value (exclusive).
  *)
  val int : int -> int
end


(*
  Exercise 4:

  Given a multiset (also known as a bag) select one element
  from it with uniform probability (so that elements which
  appear multiple times should have a higher chance to be picked).
  Or, if the bag is empty, return None.

  This operation should not be destructive or mutate the bag.

  See the (weighted) reservoir sampling algorithms
  for a simple potential approach to this.

  Note that `Bag.choose` does *not* satisfy this definition!
  (it simply picks the first element always)
*)
let sample (module R: Randomness) (b: 'a Bag.t): 'a option =
  failwith "undefined"


(*
  Now we'll define a module which holds our main functionality
  specific to a particular orderable type we'll call `Token`.

  We also need randomness here, so we will abstract over it as well.


  This module will implement a very common probabilistic model of sequences
  of elements known as the N-gram model, or sometimes the Markov model.

  TODO: INSERT GENERAL EXPLANATION FOR INTUITION! NO ADVANCED PROBABILITIES DISCUSSION, JUST CONCEPTS

  Feel free to read these useful resources to understand the basic idea further:
  - https://blog.xrds.acm.org/2017/10/introduction-n-grams-need/
  - https://web.stanford.edu/~jurafsky/slp3/slides/LM_4.pdf
  - https://medium.com/mti-technology/n-gram-language-model-b7c2fc322799

*)
module N_grams (Random: Randomness) (Token: Map.Key) = struct

  (*
    Define a module which satisfies the signature provided,
    so that sequences of tokens can be mapped to values.
  *)
  module Token_list_map : (Map.S with type key = Token.t list);;


  (*
    Based on how n-grams work, we will represent a probability distribution
    as mapping from prefixes of size `n`, to tokens which followed this prefix
    in our training corpus. The more times any particular token follows a prefix,
    the more likely it is to follow it again.
  *)
  type distribution = Token.t Bag.t Token_list_map.t

  (*
    Exercise 5:

    Given a positive integer `n` and a list of tokens,
    add each token to a new distribution as an element of the set
    corresponding to the (n-1)-gram which preceeds it.

    E.G. (with maps/bags depicted with pseudo-syntax)

      ngrams 2 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        { 
          [1] -> {2}; 
          [2] -> {3; 2; 3};
          [3] -> {4; 1};
          [4] -> {4; 4; 2};
            |        |
            |        \------- ...was followed by each of these elements
            \-- this sequence...
        }

      ngrams 3 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        {
          [1; 2] -> {3};
          [2; 3] -> {4; 1};
          [3; 4] -> {4};
          [4; 4] -> {4; 2};
          [4; 2] -> {2};
            |        |
            |        \------- ...was followed by each of these elements
            \-- this sequence...
        }

      ngrams 1 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        {
          [] -> {1; 2; 3; 4; 4; 4; 2; 2; 3; 1};
          |        |
          |        \------- ...was followed by each of these elements
          \-- this sequence...
        }
  *)
  let ngrams (n: int) (l: Token.t list): distribution =
    failwith "undefined"


  (*
    Exercise 6:

    Now, we're prepared to use the output of `ngrams` to create new,
    randomly sampled sequences.

    The arguments it expects are as follows:
    - an output from a call to `ngrams n` (above) representing a distribution
    - an integer for the maximum length of sequence to generate
    - a list of tokens (of length `n-1`) to kick-off the random generation and sequence
      (consider it like a 'seed' for you to look up in the distribution)

    It will then produce a sequence which is distributed according
    to the n-gram model it is given, terminating it either when the resulting
    sequence reaches the maximum length, or when there are no observed
    n-grams which could follow.
  *)
  let sample_sequence (dist: distribution) ~(max_length: int) ~(initial_ngram: Token.t list): Token.t list =
    failwith "undefined"
  

  (*
    Exercise 7:

    In utop, or in whatever manner is most convenient, try out the above function
    on various kinds of inputs (and instantiations of this N_grams module).

    Can you get interesting results by giving it sequences of words?
    Below, paste some sequence data which you tried inputting to `ngrams`,
    and then 3 examples of sampled sequences generated with `sample_sequences`
    and `ngrams` with different values of `n`.
  *)

  (*
    ... YOUR SEQUENCE OF DATA HERE ...
  *)

  (*
    ... YOUR OUTCOMES OF SAMPLING SEQUENCES HERE ...
  *)    
end


(*
  Exercise 8:

  Implement an executable `ngrams.exe` which can use n-gram models in several ways.

  It should expect the following arguments, with bracketed ones optional:

  $ ngrams.exe CORPUS_FILE [--sample N] [--most_frequent N] [--likelihood OBSERVATION_FILE]



  

*)