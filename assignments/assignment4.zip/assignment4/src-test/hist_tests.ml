
open OUnit2

(*
  We only provide one test on histograms.
*)

let test _ =
  let keywords =
    List.map (fun s -> Option.get (Keyword.of_string s))
      [ "let" ; "in" ; "let" ; "with" ; "with" ]
  in
  let hist = Histogram.increment_many keywords Histogram.empty in
  assert_equal "((let 2)(with 2)(in 1))" (Histogram.to_string hist)

let series =
  "Hist tests" >::: [ "Hist test" >:: test ]