
open OUnit2

(*
  ------------------
  EXECUTABLE TESTING
  ------------------

  To test the executable we capture its output and compare the result to the
  string from the expected histogram.
*)

let string_of_seq (s : char Seq.t) : string =
  let rec protect_seq seq () =
    match seq () with
    | exception End_of_file | Seq.Nil -> Seq.Nil
    | Cons (hd, tl) -> Cons (hd, protect_seq tl)
  in
  String.of_seq (protect_seq s)

let assert_string_output (message: string) (expected : string)
    (cseq : char Seq.t) : unit =
  let actual = String.trim (string_of_seq cseq) in
  assert_bool
    (Printf.sprintf
      "Failed on: %s\n- expected: %s\n- actual: %s\n"
      message expected actual)
    (String.equal expected actual)

let bin_dir = "../src/bin/" (* note that cwd is _build/default/src-test *)
let test_dir = "../test/"

let exec_name = "keywordcount.exe"
let exec_path = Filename.concat bin_dir exec_name


(* We may get timing errors when using dune exec -- src/filename.exe <args>, so
    we locate the executable and run it directly. *)
let test_exec (arg : string) (expected : string) (ctxt : test_ctxt) : unit =
  assert_command
    ~foutput:(assert_string_output (exec_path ^ " " ^ arg) expected)
    ~ctxt
    exec_path
    [ arg ]

(*
  This test checks the following command line behavior:

    $ dune exec -- ./src/bin/keywordcount.exe nested_folder_test/
    ((else 1)(if 1)(let 1)(then 1))

*)
let test_nested_counts =
  test_exec
    (test_dir ^ "nested_folder_test/")
    "((else 1)(if 1)(let 1)(then 1))"

let test_comments_counts =
  test_exec
    (test_dir ^ "comments_test/")
    "((let 8)(in 2)(match 1)(rec 1)(with 1))"

let test_strings_counts =
  test_exec
    (test_dir ^ "strings_test/")
    "((let 2)(in 1))"

let series =
  "Executable tests" >:::
  [ "Nested"   >:: test_nested_counts
  ; "Comments" >:: test_comments_counts
  ; "Strings"  >:: test_strings_counts ]