
let () =
  let s = "let these be some keywords if you mess up and don't remove strings. Else these are not keywords" in
  ()