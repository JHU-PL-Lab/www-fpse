
type t
(** [t] is a comparable, serializable type to represent an OCaml keyword. *)

val compare : t -> t -> int
(** [compare a b] is alphabetical comparison on the string representations of
    the keywords [a] and [b]. *)

val of_string : string -> t option
(** [of_string candidate] is some keyword if [candidate] is a valid OCaml
    keyword, or [None] if it is not. *)

val sexp_of_t : t -> Sexplib.Sexp.t
val t_of_sexp : Sexplib.Sexp.t -> t
