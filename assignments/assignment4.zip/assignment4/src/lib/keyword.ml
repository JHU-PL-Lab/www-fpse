
type t = Keyword of string [@@unboxed]

let compare (Keyword a) (Keyword b) =
  String.compare a b

let all_keyword_strings =
  ["and"; "as"; "assert"; "asr"; "begin"; "class"; "constraint"; "do"; "done";
  "downto"; "else"; "end"; "exception"; "external"; "false"; "for"; "fun";
  "function"; "functor"; "if"; "in"; "include"; "inherit"; "initializer";
  "land"; "lazy"; "let"; "lor"; "lsl"; "lsr"; "lxor"; "match"; "method"; "mod";
  "module"; "mutable"; "new"; "nonrec"; "object"; "of"; "open"; "or"; "private";
  "rec"; "sig"; "struct"; "then"; "to"; "true"; "try"; "type"; "val"; "virtual";
  "when"; "while"; "with"]

let of_string (candidate : string) : t option =
  if List.exists (String.equal candidate) all_keyword_strings
  then Some (Keyword candidate)
  else None

let sexp_of_t (Keyword kw) = Sexplib.Conv.sexp_of_string kw
let t_of_sexp s = Keyword (Sexplib.Conv.string_of_sexp s)
