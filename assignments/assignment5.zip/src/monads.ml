
open Core

[@@@warning "-27"]

(*
  Now that you're more comfortable with how OCaml and FP programming
  generally works, and have seen the effect on code of taking primarily immutable values and transforming them with pure functions, you may be concerned about limitations of this programming style.

  After all, isn't it very limiting to use only pure functions and never
  mutate variables? Even in OCaml, there are some imperative concessions
  made to allow exceptions to be thrown, or mutable data structures to be used.
  This recovers some kinds of control flow or algorithm designs we might 
  be more used to.  But if we disallowed ourselves from those escape hatches, 
  won't our tools be less expressive? That sounds no good.

  Fortunately, even in FP, there are certain very useful Design Patterns which
  we can use to help with these problems, and in fact formulate solutions to
  them which are even more powerful and expressive than those built-in to imperative languages.
  These are analogous to design patterns you may be familiar with in OOP, for example
  the "Visitor" design pattern which helps overcome the lack of proper variant types
  in many languages.

  Just like the visitor pattern helps make up for the lack of variant types or pattern matching,
  the "Monad" pattern solves the problem of side-effects in pure functional situations. There
  are many side-effects, of course, and so there are many examples of Monads, just like there
  could be a different implementation of the Visitor pattern for any particular family of
  classes in OOP languages. And just like the OOP design patterns, there may be some amount
  of "boilerplate" required to make the pattern work, but once it has been written, it
  can be used very easily and dramatically add to the expressiveness of code.

  With that, let's explore Monads: a design pattern for side-effects in FP.

  ******************************************************
  * All mutation and usage of exceptions in solutions  *
  * is disallowed for this assignment! Using them will *
  * invalidate your solution; so a pure, immutable,    *
  * functional approach is required. Let's go!         *
  ******************************************************

  There are many examples in the lecture notes about monads which are worth
  continuing to look over as well:
  
  http://pl.cs.jhu.edu/fpse/encoding-effects.ml
  
  Many of the monads there are duplicated here, perhaps with slight differences but
  most of the examples there can be made to work in the monads here as well.

*)


(*
  First let's motivate the existence of this solution with some scenarios
  you might reasonably expect to come across.

  Suppose in our codebase there are several functions
  which might fail to return a result. This could be because
  of a failed database query, the nonexistence of a file,
  a value being out of range, etc.

  That's fine, so we'll use the `option` type to represent
  partial functions; that is, those which might not have a result.
  Still, we need to be able to compose them together to compute our goal.
  Since each step might fail, so might their composition, of course.
  
  Here are some types in a hypothetical project we might be working in
  which interacts with a database:
*)
module type DB_types = sig
  type name
  type username
  type userinfo
  type report
  type query
  type budget
  type sentiment
end

(*
  Our examples will be hosted inside this functor module,
  so that you could provide test instantiations of the above types
  (with simple integers or strings, for example) and use them to evaluate
  the results of running your code.
*)
module Examples (DB_types : DB_types) = struct

  open DB_types

  (*
    Now suppose we need different implementations of the below
    functions, since we might use multiple databases, or just
    make a web request, etc.; so we wrap them in a module type
    so we can use this interface.
  *)
  module type Basic_db = sig
    val find_name   : username -> name option
    val build_query : username -> query option
    val exec_query  : name -> query -> userinfo option
    val make_report : name -> userinfo -> report
  end

  (*
    Exercise 1(a):

    We're equipped to write the below function.
    Fill in a reasonable definition using Option combinators
    wherever useful. 

    Follow the typechecker's guidance to make sure
    things are composed properly.
  *)
  let user_report (module DB: Basic_db): username -> report option =
    failwith "unimplemented!"
    
  (*
    Exercise 1(b):

    Comment on whether the above definition is satisfying.
    What are the issues you came across when writing it?
    How would you write code to solve a similar problem in a language
    which allows null values, or exceptions to represent failure?
  *)

  (*
    YOUR WRITTEN ANSWER HERE
  *)


  (*
    Let's also consider another interesting situation.
    Consider the next example interface which allows queries
    to the database to return multiple results.
  *)
  module type Basic_db_2 = sig
    val friends_of    : username -> username list
    val are_neighbors : (username * username) -> bool
  end

  (*
    Exercise 2(a):

    Given two input users, compute
    all pairs of their "friends of friends of friends"
    who are also neighbors, in any order.
    It is alright if the output contains duplicate pairs.
    
    That is, find the set of "friends of friends of friends"
    of each of the input users, and then return all pairs of them which satisfy `are_neighbors`.
  *)
  let neighboring_fofof (module DB: Basic_db_2): (username * username) -> (username * username) list =
    failwith "unimplemented!"


  (*
    Exercise 2(b):

    Comment on whether the above definition is satisfying.
    What are the issues you came across when writing it?
    How would you write code to solve a similar problem in a language
    which allows iterating over arrays, or mutable lists?
    What about a language that offers relational queries?
  *)

  (*
    YOUR WRITTEN ANSWER HERE
  *)


  (*
    One more motivating example, in which we want
    to get a list of reports, and tally up how they
    should affect the annual budget of tweetbook
    by considering each report in order.
  *)
  module type Basic_db_3 = sig
    val quarterly_reports : report list
    val adjust_budget     : budget -> report -> (budget * sentiment)
  end

  (*
    Exercise 3(a):

    Given a starting budget, for each of the quarterly reports,
    adjust the budget based on the report, and record the sentiment
    of that adjustment in a list.
    
    The final budget should be the result of adjusting
    based on each report in sequence, or the initial budget if there were no reports.
    The list of sentiments returned should retain the order of the quarterly reports
    used to adjust the budget.
  *)
  let finalize_budget (module DB: Basic_db_3): budget -> (sentiment list * budget) =
    failwith "unimplemented!"

  (*
    Exercise 3(b):

    Comment on whether the above definition is satisfying.
    What are the issues you came across when writing it?
    How would you write code to solve a similar problem in a language
    which allows mutable variables and lists?

    Finally, what similarities or differences have you experienced 
    between the issues in each of the three motivating example problems?

  *)

  (*
    YOUR WRITTEN ANSWER HERE
  *)


  (*
    Alright, well the cat's already out of the bag.
    This is an assignment about Monads, so we'd better unveil
    the interface itself. You've waited long enough.
  *)
  module type Monad = sig

    (*
      The carrier type of the monad.
     
      You could consider it to represent a computation returning type `'a`, 
      but with some kind of side-effect carried by `t`.
    *)
    type 'a t

    (*
      If we already have a value of type `'a`,
      we should be able to create a monadic computation of type `'a t` 
      which doesn't perform any more side-effects,
      and just produces the value we gave it.
    *)
    val return : 'a -> 'a t

    (*
      And then, the core operation of monads.
      Ignore the name for the time being, and consider the type signature.
      
      It says that we can somehow run the side-effectful computation `'a t` 
      to produce the value it holds, an `'a`. 
      
      And then, we can feed it into the function `f` to produce 
      a new side-effectful computation. This chains the two together,
      so that whatever computation `f` produces has to happen after the side-effect
      from the input.
    *)
    val bind : 'a t -> f:('a -> 'b t) -> 'b t

  end

  (*
    Monads also need to follow a few rules, in order to make sense.
    Think of these rules (or 'laws') as guidance for how you should make
    a monad work, in case it seems like there are multiple valid ways to do it.
    In these rules, `==` means that the two expressions are equivalent, i.e.
    that you can always replace one with the other and the program won't change behavior.

    If you can't make the rules work, then you probably can't really apply
    the monad design pattern to your problem. It may still be useful, but
    it might also break down in complicated or subtle situations. 


    First, there are two rules which basically enforce
    the idea that `return` does NOT add any side effects:

    1.  bind (return a) ~f           ==  f a
    2.  bind         m  ~f:return    ==    m


    And then one more rule which ensures that things
    always compose together nicely:

    3.  bind (bind m ~f:(fun a -> f a)) ~f:g   ==  
        bind m ~f:(fun a -> bind (f a) ~f:g)


    These might seem kind of cryptic or hard to understand
    in that syntax, but monads also have another trick up their sleeve in
    most languages where you can find them: a nicer alternative syntax!

    In OCaml, this is supplied by either using the `let*` operator, or
    using a ppx rewriter like Jane Street's `ppx_let`. Since we've been using
    Jane Street's Core libraries in this course, we'll use the latter approach
    for optimal compatibility.

    Using it, we can rewrite:

      bind m ~f:(fun a -> result)

    into the potentially much clearer:

      let%bind a = m in result
      

    Here's what the rules look like written this way:

    1. 
        let%bind a = return x in f a    ==  f x

    2.
        let%bind a = m in return a      ==  m

    3.
        let%bind a = m in
        let%bind b = f a in
        g b
        
        ==
        
        let%bind b = 
          (let%bind a = m in f a) 
        in g b   

    When presented this way, hopefully these rules
    seem kind of obviously true.
        

    Finally, for those who prefer, if we suppose some composition operator:

      let (=>) f g =
        fun a -> let%bind b = f a in g b

    Then the monad laws become:

    1.  (return => f)  ==  f
    2.  (f => return)  ==  f
    3.  f => (g => h)  ==  (f => g) => h

    Which shows that really, law 3 is just associativity,
    and laws 1 and 2 just say that return "does nothing".
  *)


  (*
    Alright, let's start actually showing why this is useful
    by putting this design pattern to work and solving each
    of the problems put forth so far in a simple, beautiful way.

    Starting with `option`, as it's the simplest, we'll
    work our way through defining some monads and using them.
    This is largely similar to the `Exception` monad from lecture
    if you want to reference that, as well.
  *)
  module Option_monad = struct
    module T = struct
      type 'a t = 'a option
      
      let return (x: 'a) : 'a t =
        Some x
      
      let bind (m: 'a t) ~(f: 'a -> 'b t): 'b t =
        match m with
        | None -> None 
        | Some x -> f x
      
      let map = 
        `Define_using_bind
    end
    include T
    include Monad.Make(T)
  end

  open! Option_monad
  open! Option_monad.Let_syntax


  (*
    Exercise 4(a):
    
    Give an argument for how `Option_monad` satisfies
    the monad laws, in the function below, by
    inlining the definitions of `bind` and `return`.
  *)  
  let simple : int option =
    let%bind one = return 1 in
    let%bind two = Some (one + 1) in
    return (one + two)

  (*
    YOUR WRITTEN ANSWER HERE
  *)


  (*
    Exercise 4(b):

    Use let%bind syntax to finally create a concise, elegant
    solution to the problem in Exercise 1(a).
  *)
  let user_report' (module DB: Basic_db): username -> report option =
    failwith "unimplemented!"
    

  (*
    The Option monad supports failure, but does not support
    giving information about HOW the computation failed, like
    exception-raising normally does in many imperative languages.
    
    Let's upgrade the monad to support `Result`, so that
    in the error case we can indicate exactly what went wrong.
    Make sure that the implementation abides by the monad laws!

    Notice that this version is slightly more complicated because `result`
    has two type parameters, but just follow the types and you'll be okay.
  *)
  module Result_monad = struct
    
    (*
      Exercise 5(a):
      Complete the definition of `return` and `bind`.
    *)
    module T = struct

      (*
        The type 'a is the return value of the computation,
        and the type 'e is the type of errors (e.g. `exn`, `string`)
      *)
      type ('a, 'e) t = ('a, 'e) result 

      let return (a : 'a) : ('a, 'e) t =
        failwith "unimplemented!"

      let bind (m : ('a, 'e) t) ~(f : 'a -> ('b, 'e) t): ('b, 'e) t =
        failwith "unimplemented!"

      let map =
        `Define_using_bind
    end
    include T
    include Monad.Make2(T)

    (*
      Exercise 5(b):

      Currently the Result_monad doesn't have any way for us
      to raise exceptions very intuitively, we'd have to manually
      wrap them in Error. Define a `raise` combinator to wrap
      an exception value into our monad.
    *)
    let raise (e: 'e) : ('a, 'e) t =
      failwith "unimplemented!"
    
    (*
      Exercise 5(c):
  
      Use the result monad to take in a list of `result`s, 
      and either collect all the values into a list if there
      were no errors, or return the first error encountered.
      Use combinators, rather than pattern matching on the result
      values, whenever possible.
    *)
    let collect (l : ('a, 'e) t list) : ('a list, 'e) t =
      failwith "unimplemented!"

  end


  (*
    Next, we'll take a look at the List monad,
    which represents the side-effect of nondeterminism,
    or more simply, the effect of performing an operation
    over multiple different input values automatically.

    In the lecture notes, this is called 'Nondet'.
    Feel encouraged to reference the examples there!
  *)
  module List_monad = struct
    module T = struct

      type 'a t = 'a list

      let return (a : 'a) : 'a t =
        [a]

      let bind (m : 'a t) ~(f : 'a -> 'b t) : 'b t =
        List.map ~f m |> List.concat

      let map =
        `Custom List.map

    end
    include T
    include Monad.Make(T)
  end

  open! List_monad
  open! List_monad.Let_syntax
  

  (*
    Exercise 6(a):
    
    Give an argument for how `List_monad` satisfies
    the monad laws, in the function below, by
    inlining the definitions of `bind` and `return`.

  *)  
  let simple' : int list =
    let%bind first = return 1 in
    let%bind rest =
      let%bind second = [20; 30] in
      [first; second] 
    in
    return (first + rest)

  (*
    YOUR WRITTEN ANSWER HERE
  *)


  (*
    Exercise 6(b):

    Use let%bind syntax to finally create a concise, elegant
    solution to the problem in Exercise 2(a).
  *)
  let neighboring_fofof' (module DB: Basic_db_2): (username * username) -> (username * username) list =
    failwith "unimplemented!"
    



  (*
    Now into the home stretch.
    We've discussed monads to handle the side-effect of failure,
    and the side-effect of nondeterminism, but there are other cases.
    
    Next we will study the side-effect(s) related to reading from
    some kind of global configuration, and writing to a form of log
    or memo as our computation proceeds.
  *)

  (*
    Here we show the Logger monad, also known as the "Writer"
    monad, which allows adding to some 'log' or appendable
    object during the computation, as a secondary result.
    This is by default a write-only log; without additional
    combinators outside of the base monad it cannot be read from
    within the computation.

    Usually this will represent a list of messages generated in
    the process of the main computation, or it could be used
    as a way for the function to produce a stream of values.
    The log could also be an integer representing a total,
    a set, a probability, etc. (any monoid, to be specific)
    but for simplicity we just use lists here.
  *)
  module Logger = struct
    module T = struct
  
      type 'l log = 'l list

      (* 
        Here, 'a is the returned value of the computation,
        and 'l is the type which we can log values of into a list.
      *)
      type ('a, 'l) t = 'a * 'l log
      
      let return (x : 'a) : ('a, 'l) t = 
        (x, [])

      let bind (m : ('a, 'l) t) ~(f : 'a -> ('b, 'l) t): ('b, 'l) t =
        let (a, log1) = m in 
        let (b, log2) = f a in 
          (b, log1 @ log2)
        
      let map = `Define_using_bind
  
    end
    include T
    include Monad.Make2(T)
  
    let log (msg : 'l) : (unit, 'l) t = 
      ((), [msg])
  end

  open! Logger
  open! Logger.Let_syntax


  (*
    Exercise 7(a):

    Given a positive integer `n`, write a function in the 
    Logger monad which logs integers 
    counting down from `n` to `0`.

    E.G. 
      count_down 3 = ((), [3; 2; 1; 0]).
  *)
  let count_down (n : int) : (unit, int) Logger.t =
    failwith "unimplemented!"

  (*
    Exercise 7(b):

    Given a boolean function over the type of data being logged,
    write a simple combinator which filters the output of
    one logging computation based on the function, to produce another.

    E.G.
      limit (fun x -> x > 2) (count_down 5) = ((), [5; 4; 3])
  *)
  let limit (f : 'l -> bool) (m : ('a, 'l) Logger.t) : ('a, 'l) Logger.t =
    failwith "unimplemented!" 



  (*
    Next is the Reader monad, which represents having read-only access to
    an input value at any point in the computation. This could be configurational,
    and makes it convenient to pass an extra parameter which is instantly
    visible to the computation whenever necessary, without having to explicitly
    repeatedly pass it to recursive calls, etc.

    It does not allow mutating this extra parameter however by default,
    so within one scope its value will not change without additional combinators
    outside of the base monad.
  *)
  module Reader = struct
    module T = struct
    
      (*
        As usual, 'a is the return type of the computation.
        This time, 'e is the type of the extra parameter/context.

        Notice that type `t`is a function type, so we will have to
        supply a value for the context ourselves in order to run the monadic
        computation once we've constructed it. The fact that the monad
        has to thread this extra parameter through is hidden under the hood
        by the interface provided by `let%bind`.
      *)
      type ('a, 'e) t = ('e -> 'a)
  
      let return (x : 'a): ('a, 'e) t =
        fun (_: 'e) -> x
  
      let bind (m : ('a, 'e) t) ~(f : 'a -> ('b, 'e) t) : ('b, 'e) t = 
        fun (e : 'e) -> f (m e) e
  
      let map = 
        `Define_using_bind
  
    end
    include T
    include Monad.Make2(T)
  
    (*
      This extra operation is a convenient
      way for us to access the readable state.
    *)
    let get : ('e, 'e) t = 
      fun (e : 'e) -> e 
  end

  open! Reader
  open! Reader.Let_syntax


  (*
    Exercise 8(a):
    
    Give an argument for how `Reader` satisfies
    the monad laws, in the function below, by
    inlining the definitions of `bind` and `return`.

  *)  
  let simple'' : (string, int) Reader.t = 
    let%bind n = get in
    let%bind n2 =
      let%bind n = get >>= return in
      return (n * n)
    in
    let str = string_of_int (n + n2) in
    return str

  (*
    YOUR WRITTEN ANSWER HERE
  *)
  

  module type Basic_db_4 = sig
    val get_username : userinfo -> username
    val get_report   : userinfo -> report
    val user_rating  : report -> username -> sentiment
    val user_budget  : userinfo -> username -> budget 
  end

  (*
    Exercise 8(b):

    Use the reader monad to provide a succint
    implementation of the function below. Remember
    that values of the Reader.t type are just functions!

    Make good use of the type signatures of the available
    combinators and functions to help find a clean approach.
  *)
  let user_budget_sentiment (module DB: Basic_db_4): userinfo -> sentiment * budget =
    failwith "undefined!"

  
  (*
    Time for the big one, the State monad. Disregard the hype
    and shelve your fears, though, because it's really just a combination
    of Reader and Writer. 

    Naturally, the two work together to allow both updating the state
    to a new value, and fetching the current state value. This is how
    we use the State monad to simulate mutability.

    Feel free to reference the `Count` monad shown in lecture, as it
    is just a special case of `State` for integer values.
  *)
  module State = struct
    module T = struct

      (*
        The type of stateful computations which return 'a,
        but have a potentially mutable state of type 's.

        This state will need to be provided with an initial value
        in order to run the computation, and the output will
        include the 'a value as well as the value of the state when
        the computation completed.

        To run a stateful computation, just provide it an initial state!
        It's a regular function after all.
      *)
      type ('a, 's) t = ('s -> ('a * 's))

      (*
        Consider that if we eliminated 'a from the picture, we would
        just get a type like ('s -> 's), or in otherwords we would just
        be talking about functions on the state type! So each stateful
        computation encloses such a function, and that's how putting
        them together creates a pipeline of operations which can each
        change the value.

        Conversely, if we eliminate the function part of the type,
        we'd just arrive back at something very close to Logger/Writer,
        because we removed our way of reading input. And removing
        the 's from the pair gives us just Reader again, because we have
        no way in that case to inform the NEXT computation about how we
        would like the state to change, so we lose mutability.
      *)

      (*
        If we want to construct a stateful computation which returns
        a particular value without touching the state, it's easy!
        We just pass along the input state to the output unchanged
        (because `return` should do nothing, according to monad laws)
        and use the value we were given as the result of the computation.
      *)
      let return (a : 'a) : ('a, 's) t = 
        fun (s : 's) -> (* Receive the initial state value, `s`. *)
          (a, s)        (* Produce the value `a` specified, and don't change `s` at all. *)

      (*
        What bind has to describe in a monad is fundamentally how to sequence
        two computations together. In the State case, that just means it
        has to make sure that the state value flows through both of the composed
        parts, in the right order.
      *)
      let bind (m : ('a, 's) t) ~(f: 'a -> ('b, 's) t) : ('b, 's) t =
        fun (s : 's) ->               (* Here we receive the initial state, `s`. *)
          let (a, s')  = m s in       (* Run the first computation using it, and get back an updated `s'`. *) 
          let (b, s'') = (f a) s' in  (* Then, run what f returns, using the updated state, getting a new state again. *)
            (b, s'')                  (* Return whatever `f` returned, and also the newest value for the state.  *)

      let map = 
        `Define_using_bind
    end
    include T
    include Monad.Make2(T)
       
    (*
      Behold! The two main additional combinators
      which State permits look exactly (in typing at least)
      like the combinators from Logger (AKA Writer) and Reader respectively:
    *)

    (*
      Update the state to a new value. This works
      by ignoring the input parameter, and simply
      returning the value which we told it to for the new state.
    *)
    let set (s : 's) : (unit, 's) t =
      fun _ -> ((), s)
    
    (*
      Get the value of the state. This works very simply
      by using the input parameter value as the result
      of the computation itself, and also as the state.
    *)
    let get : ('s, 's) t =
      fun s -> (s, s)
  end

  open! State
  open! State.Let_syntax


  (*
    Exercise 9(a):
    
    Give an argument for how `State` satisfies
    the monad laws, in the function below, by
    inlining the definitions of `bind` and `return`.

  *)  
  let simple''' : (int, int) State.t =
    let%bind s = get in
    let%bind one = return 1 in
    let%bind () = set (s + one) in
    let%bind s_plus_1 = get in
    let%bind () = set s in
    return s_plus_1

  (*
    YOUR WRITTEN ANSWER HERE
  *)


  (*
    Exercise 9(b):

    Given a function, produce a stateful computation
    which returns unit, but transforms the state using the input function.
    Use the state combinators and let%bind.

    E.G.
      let example = 
        let%bind () = modify (fun x -> x + 1) in
        let%bind s = get in
          return s

      example 0  =  (1, 1)

  *)
  let modify (f : 's -> 's) : (unit, 's) State.t =
    failwith "unimplemented!"


  (*
    Exercise 9(c):

    Use let%bind syntax to finally create a concise, elegant
    solution to the problem in Exercise 3(a).
  *)
  let finalize_budget' (module DB: Basic_db_3): budget -> (sentiment list * budget) =
    failwith "unimplemented!"

end