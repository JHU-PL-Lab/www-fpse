(*

FPSE Assignment 2

Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any 
problems with here, as per the course academic integrity policy.  
CAs/Prof need not be listed!

See file trees.mli for the specification of the assignment.  Recall from 
lecture that .mli files are module signatures aka module types and you
will need to provide implementations of all the functions listed there 
in this file. 

Your answers go here, plus in the cloc.ml file for the executable for Section 3.

Hint: to start out you will want to copy over the .mli file and make dummy headers
for each function similar to what we gave you for Assignment 1.
Note that .ml files need to include all `type` declarations in .mli files; some
of the .mli types are abstract (just the name) and they can start that 
way in the .ml file as well.

*)