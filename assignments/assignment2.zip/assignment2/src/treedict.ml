(*

FPSE Assignment 2

Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any 
problems with here, as per the course academic integrity policy.  
CAs/Prof need not be listed!

See file treedict.mli for the specification of Part I of the assignment,
and histo.ml for Part II.  Recall from lecture that .mli files are module 
signatures aka module types and you will need to provide implementations of all the functions listed there in this file. 

Your Part I answers go here, and the Part II answers go in the histo.ml file.

Hint: to start out you will want to copy over the .mli file and make dummy headers for each function similar to what we gave you for Assignment 1.  Recall that the syntax is slightly different in .ml and .mli  
declarations, e.g. `val` in .mli is `let` in .ml, etc.

Note that .ml files need to include all `type` declarations in .mli files.

*)
