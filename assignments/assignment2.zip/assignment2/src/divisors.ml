(*
  FPSE Assignment 2

  Name                  :
  List of Collaborators :

  Please make a good faith effort at listing people you discussed any problems
  with here, as per the course academic integrity policy.  CAs/Prof need not be
  listed!

  ------------
  INSTRUCTIONS
  ------------

  In this part of the assignment, you will implement a few functions based
  around the divisors of an integer. Provide implementations that meet the
  descriptions.

  You may define any auxiliary functions you like, and you may add `rec` to any
  function.
*)

let unimplemented () =
  failwith "unimplemented"

(* Disables "unused variable" warning from dune while you're still working. *)
[@@@ocaml.warning "-27"]

(*
  Check if a positive number is perfect: a perfect number is equal to the sum of
  its proper divisors.

  A positive divisor of `n` is called "proper" if it is different from `n`.

  For example, 28 is a perfect number:
    1 + 2 + 4 + 7 + 14 = 28
*)
let is_perfect (n : int) : bool =
  unimplemented ()

(*
  Check if positive integer `n` is prime. This should be able to quickly handle
  numbers up to 2^32.

  Performance hints:
    - You only need to rule out factors up to sqrt(n).
    - Use recursion instead of a list to save memory.
*)
let is_prime (n : int) : bool =
  unimplemented ()

(*
  Positive integers `n` and `m` are buddies if the sum of their prime divisors,
  with multiplicity, are equal.

  `are_buddies` is true if and only if `n` and `m` are buddy numbers, under this
  definition.

  For example, 1971 and 1988 are buddies:
    1971 = 3^3 * 73
    1988 = 2^2 * 7 * 71

    3 + 3 + 3 + 73 = 82 = 2 + 2 + 7 + 71
*)
let are_buddies (n : int) (m : int) : bool =
  unimplemented ()
