(*
	This file is where the code for your command-line application will go.
	We are providing you with some code to read the command line arguments.

	OCaml executables work by simply evaluating each top-level expression in the file,
	similar to a scripting language conceptually.  So all the let () = code will run.

	Feel free to modify the basic framework below as much as you want.
	Should you need or want more of the standard set of libraries
	than just `Core` and `Stdio` (and your own implementation of Part 1 and 2), 
	you will need to modify the dune file to specify this.
*)

open Core

let () =
  let target_dir = 
    match Sys.get_argv () |> Array.to_list with
    | dir :: _ -> dir
    | [] -> Sys.getcwd ()
  in
  Stdio.eprintf "Target dir: %s\n" target_dir
(* 
		Pipe together each of your sequential operations, something like:

		target_dir
    |> get_path_elt
    |> compute_metrics
    |> metrics_to_json_string
    |> print_string 
*)