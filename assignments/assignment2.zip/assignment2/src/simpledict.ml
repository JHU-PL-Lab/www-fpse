(*

FPSE Assignment 2

Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any problems with here, as per the course academic integrity policy.

See file simpledict.mli for the specification of Part I of the assignment, and keywordcount.ml for Part II.  Recall from lecture that .mli files are module signatures aka module types and you will need to provide implementations of all the functions listed there in this file. 

Your Part I answers go here, and the Part II application should go in the keywordcount.ml file.

For any auxiliary functions for Part II put them in this file as well and also add their headers to
`simpledict.mli`.  This will allow them to be run/tested without changing the dune file configuration.
Note that this is a bit sloppy, in a real app there would be a separate library file for the auxiliary
functions needed for Part II.

Hint: to start out you will want to copy over the .mli file and make dummy headers for each function similar to what we gave you for Assignment 1.  Recall that the syntax is slightly different in .ml and .mli declarations, e.g. `val` in .mli is `let` in .ml, etc.

Note that .ml files need to include all `type` declarations in .mli files.

*)
