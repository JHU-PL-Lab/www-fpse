
(*
    Part II: Core.Sys, Stdio, and making a useful utility
*)

(*
    You will be developing a simple command-line application which will compute a
    histogram of word occurrences in a whole directory tree of files.
    
    Given a directory path on the command line (or the current directory if none is given), you should:

    - traverse the directory recursively to find all text files

    - compute a histogram of word uses over all the files: sum up all
    of the occurrences over all files and sort the resulting dictionary
    from most to least common occurrence.

    - report the data to stdout in JSON format, as a JSON array of objects of the form:

        [ { "word": <word>,
            "count": <number>
          }, 
          { "word": <word>,
            "count": <number>
          } ... ]


    We need to define exactly what a "word" in a text file is; here is the 
    definition we will be using.

    * Words only include alphanumerical characters as well as `-` 
       (for "re-build" for example to be considered a word)
    * Words are case-insensitive and lower case is the canonical form
    * spaces, tabs, and newlines are word separators
    * Non-alphanumeric characters besides "-" are filtered from words.  
    So, "it's" just turns into "its".
    
    Also we need to define what is a text file.  For simplicity we
    will just use the extension on the file name and consider only
    the following extensions as text files:
      .txt, .text, .md

    Libraries for you to use:

    Any of the default set of libraries for the course may be used.
    Core.Sys and Stdio provide basics for filesystem usage and accessing argv.

    You are of course welcome to use your Part I dictionary.

    Yojson provides JSON manipulation for output.  Also, we recommend 
    `ppx_deriving_yojson` as a way to convert your own record types into 
    JSON and then strings directly.  The assignment contains links to the docs.

    Note: don't use any other opam libraries beyond the official opam libraries
    on the FPSE Coding page.

    `jq` is a command-line JSON tool which could come in handy for debugging.
*)

(*
	We are providing you with some template code below.

	OCaml executables work by simply evaluating each top-level expression in the file,
	similar to a scripting language conceptually.  So all the let () = code will run.

	Feel free to modify the code below as much as you want.
	Should you need or want more of the standard set of libraries
	than just `Core` and `Stdio` (and your own implementation of Part I), 
	you will need to modify the dune file to specify this.

    Note that if you are using `ppx_deriving_yojson` you will both need
    to list the yojson library and also add
    (preprocess
    (pps ppx_deriving_yojson))
    to the executable build in the dune file to enable the ppx macros

*)

open Core

let () =
  let target_dir = 
    match Sys.get_argv () |> Array.to_list with
    | dir :: _ -> dir
    | [] -> Sys.getcwd ()
  in
  Stdio.eprintf "Target dir: %s\n" target_dir

(* 
    Suggestion: pipe together each of your operations, something like:

		target_dir
    |> get_path_elt
    |> compute_histo
    |> histo_to_json_string
    |> print_string 
*)