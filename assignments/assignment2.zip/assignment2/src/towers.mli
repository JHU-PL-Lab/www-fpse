
type row = int list
(** A [row] is a list of integer tower heights. *)

type grid = row list
(** A [grid] is a list of rows. *)

type row_clue = int
(** A [row_clue] is the clue for a single row, the number of towers that can be
    seen by looking down that row. *)

type edge_clue = int list
(** An [edge_clue] is a list of row clues, where each integer corresponds to a
    row in a grid. *)

type grid_clue = edge_clue list
(** A [grid_clue] is a list of four edge clues, where each corresponds to one of
    the four counter-clockwise rotations of a grid. *)

(*
  -------------------
  EXPOSED FOR TESTING
  -------------------
*)

val square_size : grid -> int option
(** [square_size grid] is [Some side_length] if [grid] is a square with
    [side_length] by [side_length] elements; otherwise it is [None]. *)

val elements_span_range : row -> bool
(** [elements_span_range row] is [true] if and only if each of 1..n occur
    exactly once in [row] where [row] has length n. *)

val is_well_formed_grid : grid -> bool
(** [is_well_formed_grid grid] is true if each row and col in [grid] spans
    range, and [grid] is square with size at least 1. *)

val verify_row_clue : row -> row_clue -> bool
(** [verify_row_clue row clue] is [true] if and only if the number of towers
    seen along [row] is equal to [clue]. *)

val verify_edge_clue : grid -> edge_clue -> bool
(** [verify_edge_clue grid edge_clue] is [true] if and only if each row clue in
    [edge_clue] is correct each row in [grid]. *)

val reflect_across_vertical_axis : grid -> grid
(** [reflect_across_vertical_axis grid] is [grid] reflected across the vertical
    axis. *)

val transpose : grid -> grid
(** [transpose grid] is [grid] transposed. *)

val rotate_ccw : grid -> grid
(** [rotate_ccw grid] is [grid] rotated counter-clockwise. *)

(*
  ------------------
  MAIN FUNCTIONALITY
  ------------------
*)

val is_towers_solution : grid -> grid_clue -> bool
(** [is_towers_solution grid clue] is [true] if and only if the [grid] is well-
    formed and the edge clues in [clue] are correct for each counter-clockwise
    rotation of [grid]. *)