open Core
open OUnit2
module T = Trees


let test_depth _ =
  assert_equal 0 @@ T.depth T.Leaf;
  assert_equal 2 @@ T.depth T.(
    Branch (Leaf, 1.0, Branch (Leaf, 2.0, Leaf))
  )

let test_size _ =
  assert_equal 0 @@ T.size T.Leaf;
  assert_equal 3 @@ T.size T.(
    Branch (Branch (Leaf, 0.0, Leaf), 1.0, Branch (Leaf, 2.0, Leaf))
  )

let test_list_of_btree _ =
  assert_equal [] @@ T.list_of_btree T.Leaf;
  assert_equal [1;2;3] @@ T.list_of_btree T.(
    Branch (Branch (Leaf, 1, Leaf), 2, Branch (Leaf, 3, Leaf)))

let test_is_ordered _ =
  assert_equal true @@ T.is_ordered ~compare:Int.compare T.Leaf;
  assert_equal true @@ T.is_ordered ~compare:Int.compare T.(
    (Branch (Leaf, 1, Branch (Branch (Leaf, 2, Leaf), 3, Leaf)))
  );
  assert_equal false @@ T.is_ordered ~compare:String.compare T.(
    Branch (Branch (Leaf, "b", Leaf), "a", Leaf)
  );
;;

let section1_tests =
  "Section 1" >: test_list [
    "Depth" >:: test_depth;
    "Size"  >:: test_size;
    "List"  >:: test_list_of_btree;
    "Order" >:: test_is_ordered;
  ]

let series =
  "Assignment2 Tests" >::: [
    section1_tests;
  ]

let () = 
  run_test_tt_main series
