open Core
open OUnit2
module D = Simpledict

let d1 = D.(Branch ("d", 1.0, Branch ("a", 0.0, Leaf, Leaf), Branch ("e", 2.0, Leaf, Leaf)))

let test_size _ =
  assert_equal 0 @@ D.size D.Leaf;
  assert_equal 3 @@ D.size d1

let test_assoc_of_dict _ =
  assert_equal [] @@ D.assoc_of_dict D.Leaf;
  assert_equal ["a",0.0;"d",1.0;"e",2.0] @@ D.assoc_of_dict d1

let test_is_ordered _ = () (* fill in *)

let test_lookup _ = () (* fill in *)

let test_insert _ =
  assert_equal D.(Branch ("5", 5, Leaf, Leaf)) @@ D.insert D.Leaf "5" 5;
  assert_equal D.(Branch ("8", 1, Branch ("5", 0, Leaf, Branch ("7", 5, Branch ("6", 10, Leaf, Leaf), Leaf)), Branch ("9", -2, Leaf, Leaf))) @@ D.insert D.(Branch ("8", 1, Branch ("5", 0, Leaf, Branch ("7", 5, Leaf, Leaf)), Branch ("9", -2, Leaf, Leaf))) "6" 10

let test_map _ = () (* fill in *)

(* test_filter requires working assoc_of_dict *)
let test_filter _ =
  assert_equal [("5", "qwe"); ("6", "abc")] D.(Branch ("5", "qwe", Branch ("4", "xyz", Branch ("3", "abc", Leaf, Leaf), Leaf), Branch ("6", "abc", Leaf, Leaf)) |> filter ~f:(fun k _ -> String.(k >= "5")) |> assoc_of_dict);
  assert_equal [("7", 5); ("8", 1)] D.(Branch ("8", 1, Branch ("5", 0, Leaf, Branch ("7", 5, Leaf, Leaf)), Branch ("9", -2, Leaf, Leaf)) |> filter ~f:(fun _ v -> v > 0) |> assoc_of_dict)

let example_dict1 = D.(Branch ("9", 1, Branch ("8", 3, Branch ("1", 5, Leaf, Leaf), Leaf), Leaf))
let example_dict2 = D.(Branch ("8", 13, Branch ("1", 2, Leaf, Leaf), Branch ("99", 2, Leaf, Leaf)))

let merge_fun l r =
  match l, r with 
  | None, None -> failwith "should not get here!"
  | Some _, None -> 0
  | None, Some _ -> 1
  | Some a, Some b -> a * b

(* test_merge_with requires working assoc_of_dict *)
let test_merge_with _ =
  assert_equal [("1", 10); ("8", 39); ("9", 0); ("99", 1)] D.(merge_with ~merger:merge_fun example_dict1 example_dict2 |> assoc_of_dict)

let part1_tests = "Part 1" >: test_list [
    "Size"  >:: test_size;
    "List"  >:: test_assoc_of_dict;
    "Order" >:: test_is_ordered;
    "Lookup" >:: test_lookup;
    "Insert" >:: test_insert;
    "Map" >:: test_map;
    "Filter" >:: test_filter;
    "Merge with" >:: test_merge_with;
  ]

  (* Add another suite for any of your part II functions needing testing as well.  Make sure to put those functions in simpledict.ml and headers in simpledict.mli as only libraries are unit tested; keywordcount.ml is an executable not a library. *)
let series = "Assignment2 Tests" >::: [
    part1_tests;
    (* part2_tests; *)
  ]

let () = 
  run_test_tt_main series

