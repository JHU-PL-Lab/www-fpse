(* open Core *)
open OUnit2
open Submission

(* This file contains a few tests but not necessarily complete coverage.  You are
   encouraged to think of more tests if needed for the corner cases. 
   We will cover the details of the test syntax but with simple copy/paste it should 
   not be hard to add new tests of your own without knowing the details.
   1) Write a new let which performs the test, e.g. let test_gcd_2 = ...
   2) Add that let-named entity to one of the test suite lists such as section1_tests
      by adding e.g. 
       "GCD 2"       >:: test_gcd_2;
   Thats it!

   Recall that you need to type "dune test" to your shell to run the test suite.

*)
let test_factorial _ =
  assert_equal (factorial 0) 1;
  assert_equal (factorial 3) 6
  ;;

let test_fibonacci _ =
  assert_equal (fibonacci 0) 0;
  assert_equal (fibonacci 1) 1
  ;;

let test_choose _ =
  assert_equal (choose 2 1) 2;
  assert_equal (choose 2 2) 1;
  assert_equal (choose 7 3) 35
  ;;

let test_gcd _ =
  assert_equal (gcd 1000 1001) 1;
  assert_equal (gcd 20 10) 10
  ;;

let section1_tests =
  "Section 1" >: test_list [
    "Factorial" >:: test_factorial;
    "Fibonacci" >:: test_fibonacci;
    "Choose"    >:: test_choose;
    "GCD"       >:: test_gcd;
  ]
  



let test_iota1 _ =
  assert_equal (iota1 5) [5; 4; 3; 2; 1]
  ;;

let test_iota2 _ =
  assert_equal (iota2 6) [1; 2; 3; 4; 5; 6]
  ;;

let test_factors _ =
  assert_equal (factors 10) [1; 2; 5; 10];
  assert_equal (factors 12) [1; 2; 3; 4; 6; 12]
  ;;

let section2_tests =
  "Section 2" >: test_list [
    "Iota1"   >:: test_iota1;
    "Iota2"   >:: test_iota2;
    "Factors" >:: test_factors;
  ]


let test_product _ =
  assert_equal (product [1; 2; 3]) 6;
  assert_equal (product []) 1
  ;;

let test_mean _ =
  assert_equal (mean [10.0; 20.0; 30.0]) 20.0;
  assert_equal (mean [1.0]) 1.0
  ;;

let test_mean_differences _ =
  assert_equal (mean_differences [10.0; 20.0; 30.0]) [-10.0; 0.0; 10.0]
  ;;

let test_std_dev _ =
  assert_equal true @@ cmp_float (std_dev [10.0; 20.0; 30.0]) 8.1649
  ;;

let test_cutoff_probability _ =
  assert_equal true @@ cmp_float
    (cutoff_probability 20.0 [10.0; 20.0; 30.0]) 0.5;
  assert_equal true @@ cmp_float
    (cutoff_probability 30.0 [10.0; 20.0; 30.0]) 0.1103
  ;;

let section3_tests = 
  "Section 3" >: test_list [
    "Product"            >:: test_product;
    "Mean"               >:: test_mean;
    "Mean Differences"   >:: test_mean_differences;
    "Standard Deviation" >:: test_std_dev;
    "Cutoff Probability" >:: test_cutoff_probability;
  ]




let test_nth_opt _ =
  assert_equal (nth_opt 5 [1; 2; 3; 4; 5; 6]) (Some 6)
  ;;

let test_zip _ =
  assert_equal (zip [1; 2; 3] ["a"; "b"; "c"])
    (Ok [(1, "a"); (2, "b"); (3, "c")])
  ;;

let test_student_record1: student_record =
  [
    Ok (Some 10.0);
    Ok (Some 10.0);
    Ok (None);
  ]

let test_student_record2: student_record =
  [
    Error "No such item.";
    Ok (Some 100.0);
    Ok (Some 100.0);
  ]

let test_mean_of_record _ =
  assert_equal (mean_of_record test_student_record1) (Some 10.0)
  ;;
  
let test_mean_of_record' _ =
  assert_equal (mean_of_record' test_student_record1) (20.0, [])
  ;;

let section4_tests =
  "Section 4" >: test_list [
    "Nth-Opt"              >:: test_nth_opt;
    "Zip"                  >:: test_zip;
    "Mean of Record"       >:: test_mean_of_record;
    "Mean of Record (alt)" >:: test_mean_of_record';
  ]




let test_is_prime _ =
  assert_equal (is_prime 2) true;
  assert_equal (is_prime 4) false
  ;;

let test_primes_up_to _ =
  assert_equal (primes_up_to 10) [2; 3; 5; 7]
  ;;

let test_prime_factors _ =
  assert_equal (prime_factors 40) [2; 2; 2; 5]
  ;;

let test_run_length_encode _ =
  assert_equal (run_length_encode [1; 1; 2; 3; 3; 3; 4; 1; 1])
    [(1, 2); (2, 1); (3, 3); (4, 1); (1, 2)]
  ;;

let test_run_length_decode _ =
  assert_equal (run_length_decode [(1, 2); (2, 1); (3, 3); (4, 1); (1, 2)])
    [1; 1; 2; 3; 3; 3; 4; 1; 1]
  ;;

let test_smallest_divisible_by _ =
  assert_equal (smallest_divisible_by [1; 2; 3; 4; 5; 6; 7; 8; 9; 10]) 2520
  ;;


let section5_tests =
  "Section 5" >: test_list [
    "Is Prime"              >:: test_is_prime;
    "Primes up to"          >:: test_primes_up_to;
    "Prime factors"         >:: test_prime_factors;
    "Run-length encode"     >:: test_run_length_encode;
    "Run-length decode"     >:: test_run_length_decode;
    "Smallest divisible by" >:: test_smallest_divisible_by;
  ]




let series =
  "Assignment1 Tests" >::: [
    section1_tests;
    section2_tests;
    section3_tests;
    section4_tests;
    section5_tests;
  ]


let () = run_test_tt_main series
