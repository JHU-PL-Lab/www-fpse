(*
  FPSE Assignment 1

  Name                  :
  List of Collaborators :

  Please make a good faith effort at listing people you discussed any problems
  with here, as per the course academic integrity policy. CAs/Prof need not be
  listed!

  Note that it is strictly illegal to look for direct answers to these questions
  using search or AI tools. For example asking ChatGPT "how do I implement a
  least common multiple function in OCaml" is illegal.

  Fill in the function definitions below by replacing the

    unimplemented ()

  with your code. You may add `rec` to any function to make it recursive. You
  may define any auxillary functions you'd like and reorder the functions.

  You may not use the `List` module functions in this assignment, but you may
  use other standard library module. In the next assignment, we will start using
  `List`.
*)

(*
  Here is a simple function which gets passed unit, (), as argument and raises
  an exception. It is the initial implementation of all functions below.
*)
let unimplemented () =
  failwith "unimplemented"

(* Disables "unused variable" warning from dune while you're still working. *)
[@@@ocaml.warning "-27"]

(*
  All functions must be total for the specified domain; overflow is excluded
  from this restriction but should be avoided.
*)

(*
  Given a non-negative integer `n`, compute `0+1+2+ ... +n` using recursion.
  Do not use the closed-form solution. Do the actual addition.
*)
let summate (n : int) : int =
  unimplemented ()

(*
  Given non-negative integers `n` and `m`, compute their least common multiple.
*)
let lcm (n : int) (m : int) : int =
  unimplemented ()

(*
  Given a non-negative integer `n`, compute the n-th fibonacci number. Give an
  implementation that does not take exponential time; the naive version from
  lecture is exponential since it has two recursive calls for each call.
*)
let fibonacci (n : int) : int =
  unimplemented ()

(*
  Given non-negative integers `a` and `b`, where `a` is not greater than `b`,
  produce a list [a; a+1; ...; b-1].
*)
let range (a : int) (b : int) : int list =
  unimplemented ()

(*
  Given integers `n`, `d`, and non-negative `k`, produce the arithmetic
  progression [n; n + d; n + 2d; ...; n + (k-1)d].
*)
let arithmetic_progression (n : int) (d : int) (k : int) : int list =
  unimplemented ()

(*
  Given non-negative integer `n`, produce the list of integers in the range (0,
  n] which divide n, in ascending order.
*)
let factors (n : int) : int list =
  unimplemented ()

(*
  Reverse a list. Your solution must be in O(n) time. Note: the solution in
  lecture is O(n^2).
*)
let reverse (ls : 'a list) : 'a list =
  unimplemented ()

(*
  Given a list of lists, flatten it into a single list.

  Example:
    `flatten [[1; 2]; [3]; [4; 5]]` is `[1; 2; 3; 4; 5]`
*)
let flatten (lss : 'a list list) : 'a list =
  unimplemented ()

(*
  Given a list of integers, return a new list with consecutive dupliates
  removed.
*)
let compress (ls : int list) : int list =
  unimplemented ()

(*
  Given a list of strings, check to see if it is ordered, i.e. whether earlier
  elements are less than or equal to later elements.
*)
let is_ordered (ls : string list) : bool =
  unimplemented ()

(*
  Given a non-empty list of strings, return the lexicographically greatest
  string from the list, as well as the list without that greatest string.

  If there are duplicates of the greatest string, remove the instance that
  occurs last in the list.
*)
let remove_max (ls : string list) : string * string list =
  unimplemented ()

(*
  Sort a string list using selection sort. Your solution must have time
  complexity O(n^2). Note that time complexity will depend on your
  implementation of `remove_max`.

  The resulting list must be sorted from smallest to largest string
  lexicographically.
*)
let selection_sort (ls : string list) : string list =
  unimplemented ()
