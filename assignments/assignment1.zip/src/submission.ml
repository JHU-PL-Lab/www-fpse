(*

FPSE Assignment 1
 
Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any 
problems with here, as per the course academic integrity policy.  
CAs/Prof need not be listed!

Fill in the function definitions below replacing the 

  unimplemented ()

with your code.  Feel free to add "rec" to any function listed to make
it recursive. In some cases, you will find it helpful to define
auxillary functions, feel free to.

Several of the questions below involve computing well-known mathematical functions;
if you are not familiar with the function named your trusty search engine
should be able to give you an answer, and feel free to ask on Piazza.

You must not use any mutation operations of OCaml for any of these
questions (which we have not taught yet in any case): no arrays,
for- or while-loops, references, etc.

*)

(* Disables "unused variable" warning from dune while you're still solving these! *)
[@@@ocaml.warning "-27"]

(* You are required to use the Core libraries, don't remove the following line.
   If the editor is not recognizing Core (red squiggle under it for example),
   run a "dune build" from the shell -- the first time you build it will create some
   .merlin files which tells the editor where the libraries are.
*)
open Core

(* Here is a simple function which gets passed unit, (), as argument
   and raises an exception.  It is the initial implementation below. *)

let unimplemented () =
	failwith "unimplemented"
	
(*
	Section 1: simple numeric recursions.
	
	All functions must be total for the specified domain;
	overflow is excluded from this restriction but should be avoided.
	
*)

(*
	Given a non-negative integer `n`, compute n factorial.
*)
let factorial (n: int): int =
	unimplemented ()

(*
	Given a non-negative integer `n`, compute the n-th fibonacci number.
	This should not take exponential time (the naive version from lecture is exponential).
*)
let fibonacci (n: int): int =
	unimplemented ()

(*
	Given non-negative integers `n` and `k`, compute the mathematical function `n choose k`.
*)
let choose (n: int) (k: int): int =
	unimplemented ()

(*
	Given non-negative integers `n` and `m`, compute their greatest common denominator.
*)
let gcd (n: int) (m: int): int =
	unimplemented ()


(*
	Section 2: building lists.	The List module functions may NOT be used (yet).
*)
	
(*
	Given a non-negative integer `n`, produce a list [n; n-1; ...; 2; 1].
*)
let iota1 (n: int): int list =
	unimplemented ()
	
(*
	Given a non-negative integer `n`, produce a list [1; 2; ...; n-1; n],
	without taking O(n^2) time.
*)
let iota2 (n: int): int list =
	unimplemented ()
	
(*
	Given a positive integer `n`, produce the list of integers in the range (0, n]
	which it is divisible by, in ascending order.
*)
let factors (n: int): int list =
	unimplemented ()
	
	
(*
	Section 3: Consuming lists.	The List module functions may NOT be used.
*)
	
	
(*
	Given a list of integers `ns`, compute their product.
*)
let product (ns: int list): int =
	unimplemented ()
	
(*
	Given a nonempty list of floats `rs`, compute their mean.
	(Recall that the basic operations like * + etc on floats need
	to be written as *. +. etc in OCaml - the "." is the float version.)
*)
let mean (rs: float list): float =
	unimplemented ()

(*
	Given a list of floats `rs`, compute a list of floats containing 
	each number's difference from their mean.
	
	This list should retain the same order as `rs` and should take O(n) time.
*)
let mean_differences (rs: float list): float list =
	unimplemented ()
	
(*
	Given a nonempty list of floats `rs`, compute their standard deviation.
*)
let std_dev (rs: float list): float =
	unimplemented ()


(*
	Section 4: Simple error handling.
	Use option and result types here, but do not use the List module functions.
*)

(*
	Given a list `l`, and an integer `n`, return the n-th element of l if it exists,
	otherwise return None.
*)
let nth_opt (n: int) (l: 'a list): 'a option =
	unimplemented ()

(*
	Given lists `l1` and `l2`, produce a list containing the pairwise elements in a tuple.
	
	If the lists have uneven length, return Error
	with a suitable message.
*)
let zip (l1: 'a list) (l2: 'b list): (('a * 'b) list, string) result =
	unimplemented ()

(*
	Consider a student record as a list of Results of scores.
	Each entry will be Ok if the entry was retrieved, or an Error otherwise.
	The scores may be None, if the student did not complete the assignment.
	
	Given a student record, compute the mean of the existing scores, or None.
	In the case that one of the entries is an Error, throw an exception.
*)
type student_record = (float option, string) result list

let mean_of_record (es: student_record): float option =
	unimplemented ()

(*
	Given a student record as before, compute the mean of the scores.
	Assume that the scores do exist, and throw an exception otherwise.
	Collect each of the Error branches into a list of errors and return this too.
*)
let mean_of_record' (es: student_record): float * string list =
	unimplemented ()


(*
	Section 5: Building and consuming, using libraries.
*)

(*
	Part 1: for the selected functions in Sections 2 and 3, provide
	a reimplementation of your previous code by refactoring
	the definition to use combinators provided by the List module.
	
	Care should be taken to use a concise, elegant combination
	of these provided functions to best express the task.
	
	These new implementations should not need to be explicitly recursive.
*)

let iota1' (n: int): int list = 
	unimplemented ()

let iota2' (n: int): int list =
	unimplemented ()

let factors' (n: int): int list =
	unimplemented ()

let product' (ns: int list): int =
	unimplemented ()

let mean' (rs: float list): float = 
	unimplemented ()

let mean_differences' (rs: float list): float list = 
	unimplemented ()

let std_dev' (rs: float list): float = 
	unimplemented ()

(*
	Part 2: novel problems using List module
	All code written in part 1 may be reused when necessary.
	
	Helper functions which simplify one or more definitions
	are encouraged, and although it may not be required,
	introducing recursion or mutual recursion is also allowed.
	
	Use the List combinators, pipelining, etc. when possible
	and whenever it improves the readability of the solution.
*)

(*
	Given a positive integer `n`, determine whether it is prime.
*)
let is_prime (n: int): bool = 
	unimplemented ()

(*
	Given a positive integer `n`, produce the ascending list of prime numbers <= n.
*)
let primes_up_to (n: int): int list = 
	unimplemented ()

(*
	Given a positive integer `n`, produce the ascending list of the prime factors of n.
*)
let prime_factors (n: int): int list = 
	unimplemented ()

(*
	Given a list of integers, produce a list which pairs repeated integers
	with the number of times they repeated.
	E.G.
		run_length_encode [1; 1; 25; 4; 4; 4; -3; 1; 1] =
			[ (1, 2); (25, 1); (4, 3); (-3, 1); (1, 2) ]
*)
let run_length_encode (ns: int list): (int * int) list = 
	unimplemented ()

(*
	Given a list of values paired with repetition counts,
	produce the list which contains each value repeated the
	correct number of times.
	I.E.
		invert the previous function's transformation.
*)
let run_length_decode (ps: (int * int) list): int list = 
	unimplemented ()

(*
	Given a list of positive integers, compute the smallest integer which is evenly
	divisible by each of the integers in the list.
*)
let smallest_divisible_by (ns: int list): int = 
	unimplemented ()
	






