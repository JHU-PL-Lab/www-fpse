
(*
  The state monad is a function to allow you to "thread" the state through.
  Implement this signature in `state_m.ml`, and use `Monad.Make` after writing
  your `bind` and `return` functions.

  Then, implement the state-specific `get`, `modify`, and `run` functions.

  See the lecture notes and the `State` module for a very similar
  implementation.
*)

(* The type of the state is State.t *)
module Make (State : sig type t end) : sig
  include Monad.S with type 'a m = State.t -> 'a * State.t

  val get : State.t m
  (** [get] is a monadic value whose data is the state. *)

  val modify : (State.t -> State.t) -> unit m
  (** [modify f] applies [f] to the state. *)

  val run : State.t -> 'a m -> 'a * State.t
  (** [run init x] is the value and final state from [x], given the initial
      state [init]. *)
end
