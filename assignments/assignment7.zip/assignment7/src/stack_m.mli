
(*
  Use `State_m` and `Monad` to implement a stateful monadic stack.  Note you
  shouldn't have to write new `bind` and `return` functions but can instead
  include those from `State_m`.
*)

module Make (Elt : sig type t end) : sig
  include module type of State_m.Make (struct type t = Elt.t list end)
  (** A stack monad is a state monad where the state is [Elt.t list]. *)

  (*
    We'll need a few extra functions to use this monad practically, so
    we have the following in addition to the above signature.
  *)

  val push : Elt.t -> unit m
  (** [push a] is a monadic unit value that has [a] on the top of the stack. *)

  val is_empty : bool m
  (** [is_empty] is a monadic value whose underlying data is true if and only if
      the stack is empty *)

  val pop : Elt.t option m
  (** [pop] is a monadic value whose underlying data is the top value of the
      stack, and the new state no longer has the top value, if there was any
      top value. *)

  val run : 'a m -> 'a
  (** [run x] takes [x] out of monad-land by providing an initial empty stack
      and throwing away the final stack. Recall that ['a] is the underlying data
      type. From this signature, we see that the data in the stack is thrown
      away, and the underlying data is kept. *)
end
