(*
  FPSE Assignment 7

  Name                  :
  List of Collaborators :

  In this file you use the `Stack_m` monad module to refactor some stateful
  OCaml code.

  Only begin on this file after finishing the `Monad`, `State_m`, and `Stack_m`
  modules.
*)

module Char_stack = Stack_m.Make (Char)

open Char_stack
open Char_stack.Syntax

(*
  -------------
  EXAMPLE USAGE
  -------------

  This is an example usage of the stack monad. Note this doesn't run yet because
  the state monad puts a `fun ... ` around all of it.

  Recall that the `let*` notation (which is in scope because of the
  `open Char_stack.Syntax` above) is monadic bind.
*)
let simple_stack : 'a m =
  let* () = push 'a' in
  let* () = push 'b' in
  let* () = push 'c' in
  let* c_opt = pop in
  match c_opt with
  | Some c -> return (Char.equal c 'c')
  | None -> return false

(*
  Alternatively, we can use `let+` (map) to implicitly return the final
  expression.
*)
let simple_stack' : 'a m =
  let* () = push 'a' in
  let* () = push 'b' in
  let* () = push 'c' in
  let+ c_opt = pop in
  match c_opt with
  | Some c -> Char.equal c 'c'
  | None -> false

(* This will now run each of the above and assert they each return true. *)
let () = assert (run simple_stack && run simple_stack')

(*
  ---------------------
  MUTABLE STACK PROGRAM
  ---------------------

  We'll now look at a simple mutable-stack program.

  The program checks if a string `s` has all parentheses '(' and ')' balanced.
  It uses the `Stack` module from the standard library, which is an actual
  mutable stack, not a monadic encoding of one.
*)

(** [are_balanced_mutable s] is true if and only if the string [s] is a string
    of opening '(' and closing ')' parentheses that are balanced.
    This implementation returns [false] if we catch an exception from an illegal
    pop. *)
let are_balanced_mutable (s : string) : bool =
  let stack_of_lefts = Stack.create () in
  let parse = function
    | '(' -> Stack.push '(' stack_of_lefts; true
    | ')' -> Char.equal '(' (Stack.pop stack_of_lefts)
    | _ -> true
  in
  let main str =
    let are_balanced = String.fold_left (fun b c -> b && parse c) true str in
    let are_all_matched = Stack.is_empty stack_of_lefts in
    are_balanced && are_all_matched
  in
  try main s with Stack.Empty -> false

(*
  And now you will refactor the mutable-stack program into a program with the
  same structure and functionality by using our `Char_stack` monad in place of a
  mutable stack.

  Rewrite the above function by turning all of the mutable stack operations into
  `Char_stack` ones. You may not use any mutable state. You must use
  `Char_stack` for all stack operations, and you must *not* use `Stack`;
  you must write the program monadically.

  To make things more clear, we will extract some of the auxiliary functions we
  had above as separate functions with types declared for your benefit. Pay
  close attention to those types: the auxiliary functions are returning monadic
  values.
*)

let parse (c : char) : bool m =
  failwith "FILL THIS IN"

let main_monadic (s : string) : bool m =
  failwith "FILL THIS IN"

let are_balanced_monadic (s : string) : bool =
  run @@ main_monadic s

(*
  And that's it! Now go test your code thoroughly in `test/tests.ml` and answer
  the discussion question in `discussion.txt`.
*)