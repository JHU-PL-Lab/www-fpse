
(*
  ----------
  BACKGROUND
  ----------

  In this assignment you'll create and use a stateful stack monad. This will be
  done by writing a functor that makes most of a monad module's functions for
  you.

  You'll then use the functor to make your stack monad module, write a few extra
  helpful functions, and use that module in a simple program.

  Recall the monads lecture here:

    https://pl.cs.jhu.edu/fpse/lecture/encoding_effects.ml

  To write the Monad `Make` module, you will follow a type-directed programming
  approach. It may seem challenging to implement everything described by this
  `mli`, but if you follow the types and think about the only way to implement
  the functions, you'll get there. Think about what you are given (the inputs to
  the function), what you have at your disposal (only what is passed in as the
  `BASIC` module), and what you need to construct.
*)

(*
  -----------
  BASIC MONAD
  -----------

  Our basic monad will have a parametrized type and two functions:
  * [bind] "maps" the given monad by [f]
  * [return] creates a monad from the given underlying value

  Note that in lecture we say a monad is anything matching some different
  general module type than `BASIC` below (it is the `Monadic` module in the
  lecture notes), but we are simplifying it for this assignment.
*)
module type BASIC = sig
  type 'a m

  val bind : 'a m -> ('a -> 'b m) -> 'b m

  val return : 'a -> 'a m
end

(*
  ---------------
  MONAD SIGNATURE
  ---------------

  Provided the type and functions in the `BASIC` monad, we can create
  all of the following functions in the signature `S` to give ourselves
  more operations on the monad.

  We give you some hints for which functions from `BASIC` you might use to
  implement each function in `S`.
*)
module type S = sig
  include BASIC

  val map : ('a -> 'b) -> 'a m -> 'b m
  (** [map] is implemented using [bind] and [return]. *)

  val join : 'a m m -> 'a m
  (** [join] is implemented using [bind]. *)

  module Syntax : sig
    val ( let* )  : 'a m -> ('a -> 'b m) -> 'b m
    (** [let*] is [bind] in let-notation. *)

    val ( let+ )  : 'a m -> ('a -> 'b) -> 'b m
    (** [let+] is [map] in let-notation. *)
  end

  module Infix : sig
    val (>>=) : 'a m -> ('a -> 'b m) -> 'b m
    (** [>>=] is infix [bind]. *)

    val (>>|) : 'a m -> ('a -> 'b) -> 'b m
    (** [>>|] is infix [map]. *)
  end
end

(*
  ------------
  MAKE FUNCTOR
  ------------

  The functor `Make` has the signature `MAKE`, which takes a `BASIC` module and
  produces an `S` module. Use the hints above to implement this in `monad.ml`.
*)
module type MAKE = functor (M : BASIC) -> S with type 'a m = 'a M.m

module Make : MAKE

(*
  --------------------------
  MODULE-DEPENDENT FUNCTIONS
  --------------------------

  And, just for fun, we will use OCaml 5.5's new module-dependent functions to
  write a monadic `all` function.

  Here are two examples, provided Option and Result are monads (they do not
  define the `return` function, but they do define `bind`).
  - `all (module Option)` is a function that takes a list of options and returns
    a list of the underlying values only if all of the options are Some.
    Otherwise, it is None.
  - `all (module Result)` is a function that takes a list of results and returns
    a list of the underlying values only if all of the results are Ok.
    Otherwise, it is the first Error occurring in the list.
*)

val all : (module M : BASIC) -> 'a M.m list -> 'a list M.m
(** [all ls] is the list of underlying values in [ls] bound left to right. *)
