(*
  An example use of Map; somewhat solves 
  https://github.com/exercism/ocaml/tree/master/exercises/grade-school
*)

(* 
  The Make functor in the Map module specializes maps to Ints in this case 
  See https://ocaml.org/manual/5.5/api/Map.S.html for the Map module API.
*)

module IntMap = Map.Make (Int)

(*
  The Int here is the **keys** of the map (the grade here); we need to use
  a functor because we need an underling compare function for maps to work.
  Built-in Int has such. 
   
  Here is the module type of Make's argument, the OrderedType module type:

      #show Map.OrderedType;;
      module type OrderedType = sig type t val compare : t -> t -> int end
            
  So Int needs to have the underlying type t (= int here), and compare. Fortunately, it does.
*)

(*
  We are defining the School module as this file; let us follow convention and
  name "its" underlying data type t.  
  Note that IntMap has one type parameter which is the type of the map's value
  data -- string list for a School.
  (The functor only needs the key type since compare is not needed on values,
  so the type of values is parametric.)
*)
type t = (string list) IntMap.t

(*   
  Informal shape of a School.t map: 
    { 1 |-> ["Bob"; "Sue"]
    , 3 |-> ["Yohan"; "Idris"] }
*)

(* The empty school *)
let empty : t = IntMap.empty

(*
  From now on we need to use Map.add etc directly and not IntMap.add etc
    - the empty map has in its type the type of keys and how to compare them,
     and we build all the maps from that.
*)

(** 
  Add a student [stud] in grade [grade] to [school] database.
  [Map.add_to_list] assumes values are lists and conses to key's
  associated list or, if the key is not present, it creates a
  new key and singleton list.
*)
let add (grade : int) (stud : string) (school : t) : t =
  IntMap.add_to_list grade stud school

(** 
  Sorting using a fold over the map.
  [sort] below will alphabetically sort the students in each grade.
  Folding over a map is like folding over a list but the folding
  function uses both key and value.
*)
let sort (school : t) : t = 
  IntMap.fold (fun key data scl ->
      IntMap.add key (List.sort compare data) scl
    ) school
    empty


(**
  Note that [IntMap.map] is a better way; it maps over the values only,
  keeping the key structure intact.
*)
let sort_better_with_map (school : t) : t = 
  IntMap.map (fun data ->
    List.sort compare data
  ) school


(** Auxiliary function to dump data structure *)
let dump (school : t) = school |> IntMap.to_list 

let roster (school : t) = school |> sort |> dump

(** Simple test *)
let test_school = empty |> add 2 "Ku" |> add 3 "Lu" |> add 9 "Mu" |> add 9 "Pupu"  |> add 9 "Apu"
