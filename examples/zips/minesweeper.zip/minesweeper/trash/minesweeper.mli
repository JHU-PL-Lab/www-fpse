(** Minesweeper exercise *)

val annotate : string list -> string list
(** Annotate empty spots next to mines with the number of mines next to them. *)
