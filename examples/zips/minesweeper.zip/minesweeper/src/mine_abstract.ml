(* Make the grid more well-typed and not just characters *)
(* Builds on mine_array.ml *)

(* Array_2d as in mine_array.ml *)

(* TODO: make this an immutable array *)

module Array_2d = struct
  type 'a t = 'a array array

  let get (b : 'a t) (x : int) (y : int) : 'a option =
    try Some(b.(x).(y)) with _ -> None

  let mapxy (b : 'a t) (f : int -> int -> 'a -> 'b) : 'b t =
    Array.mapi (fun y r -> Array.mapi (f y) r) b

  let adjacents (b : 'a t) (x : int) (y : int) : 'a list =
    let g xo yo = get b (x + xo) (y + yo) in
    List.filter_map Fun.id
      [
        g (-1) (-1); g 0 (-1); g 1 (-1); g (-1) 0; g 1 0; g (-1) 1; g 0 1; g 1 1;
      ]
end

(* Lets make types specifying exactly the cell content types 
   on input and output grids respectively
   Unfortunately we need different names for mines in the two types, so we use Mine_in and Mine_out *)

type input_cell = Mine_in | Empty
type output_cell = Mine_out | Count of int

let to_result n = Count(n)

(* Convert an output_cell to the corresponding string.*)
let count_to_string = function 
  | Mine_out -> "*"
  | Count(0) -> " "
  | Count(n) -> Int.to_string n

let is_mine s = match s with Empty -> false | Mine_in -> true

let is_field = Fun.negate is_mine

(* Conversion is now a little bit more work.  For the input lets
   1) read it in as a char Array_2d.t
   2) convert that to a input_cell Array2d.t  *)

let from_string_list (l : string list) : input_cell Array_2d.t =
  let char_array : char Array_2d.t = 
    (Array.of_list (List.map (fun s -> Array.init (String.length s) (String.get s)) l)) in
  Array_2d.mapxy char_array (fun _ _ c -> if c = ' ' then Empty else Mine_in)

  let to_string_list (board : output_cell Array_2d.t) : string list =
  Array.fold_left (fun accum_l a ->
      accum_l
      @ [ Array.fold_left (fun accum c -> accum ^ count_to_string c) "" a])
      [] board
(* Main calculation: annotate a board of mines; similar to minesweeper.ml *)

let array_annotate (board : input_cell Array_2d.t) : output_cell Array_2d.t =
  let count_nearby_mines x y =
    Array_2d.adjacents board x y |> fun l -> List.length (List.filter is_mine l)
  in
  Array_2d.mapxy board (fun x y c ->
      if is_field c then count_nearby_mines x y |> to_result else Mine_out)

(* Overall function requires conversion functions in pipeline, no big deal. *)      
let annotate (l : string list) : string list =
  l |> from_string_list |> array_annotate |> to_string_list
