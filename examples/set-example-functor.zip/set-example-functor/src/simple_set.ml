(* simple_set.ml revised for functor-land
   Defines the functor Make which allows us to build sets with comparison built-in
*)
open Core

module type Eq = sig
  type t
  val equal : t -> t -> bool
end

(* This is a functor which will make a simple set at type defined in Eq *)
module Make (M : Eq) = struct

  type t = M.t list
  let emptyset : t = []
  let add (x : M.t) (s : t) : M.t list = x :: s

  let rec remove (x : M.t) (s : t) =
    match s with
    | [] -> failwith "item is not in set"
    | hd :: tl -> if M.equal hd x then tl else hd :: remove x tl

  let rec contains (x : M.t) (s : t) =
    match s with
    | [] -> false
    | hd :: tl -> if M.equal x hd then true else contains x tl
end
