(* modify Array version to be more precise on data in the array *)
open Core

(* Let us pull out the immutable 2D array stuff into its own module, instead of Board *)
(* Why? A 2D immutable array is a very clear abstraction boundary, we know exactly what it is *)
(* This struct is a generic 2D immutable array, nothing here is for minesweeper only *)
(* Lets also use actual arrays.  Since grids don't get extended/shunk lists have no advantage *)
(* This shows we can use arrays functionally, we don't mutate it but we get O(1) access benefit *)
module Array_2d = struct
  type 'a t = 'a array array

(* The following functions are much more sensible with an OCaml array *)
  let get (b : 'a t) (x : int) (y : int) : 'a option =
    Option.try_with (fun () -> b.(x).(y))

  let mapxy (b : 'a t) ~(f : int -> int -> 'a -> 'b) : 'b t =
    Array.mapi b ~f:(fun y r -> Array.mapi r ~f:(f y))

  let adjacents (b : 'a t) (x : int) (y : int) : 'a list =
    let g xo yo = get b (x + xo) (y + yo) in
    List.filter_opt (* same as List.filter_map ~f:Fn.id *)
      [
        g (-1) (-1); g 0 (-1); g 1 (-1); g (-1) 0; g 1 0; g (-1) 1; g 0 1; g 1 1;
      ]
end

type grid_cell = Empty | Mine
type result_cell = Mine_out | Count of int

let to_result n = Count(n)
let count_to_string = function 
  | Mine_out -> "0"
  | Count(n) -> Int.to_string n

let is_mine s = match s with Empty -> false | Mine -> true

let is_field = Fn.non is_mine

(* Need conversion functions to/from list of strings format since tests are that form *)

let from_string_list (l : string list) : grid_cell array array =
  let char_array : char Array_2d.t = (List.to_array (List.map l ~f:(fun s -> String.to_array s))) in
  Array_2d.mapxy char_array ~f:(fun _ _ c -> if Char.(c = ' ') then Empty else Mine)
let to_string_list (board : result_cell Array_2d.t) : string list =
  Array.fold board ~init:[] ~f:(fun accum_l a ->
      accum_l
      @ [ Array.fold a ~init:"" ~f:(fun accum c -> accum ^ count_to_string c) ])

(* Main calculation: annotate a board of mines; similar to minesweeper.ml *)

let array_annotate (board : grid_cell Array_2d.t) : result_cell Array_2d.t =
  let count_nearby_mines x y =
    Array_2d.adjacents board x y |> List.count ~f:is_mine
  in
  Array_2d.mapxy board ~f:(fun y x c ->
      if is_field c then count_nearby_mines x y |> to_result else Mine_out)

(* Overall function requires conversion functions in pipeline, no big deal. *)      
let annotate (l : string list) : string list =
  l |> from_string_list |> array_annotate |> to_string_list
